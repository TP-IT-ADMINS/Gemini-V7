﻿    
    

	var cs_colors = {
	                theme_color : "#356aa0",
				
				                theme_color_secondary : "#6d9dce",
				
				                theme_color_gradient : "#6d9dce",
				
				                color_green : "#41a241",
				
				                color_red : "#d42f2f",
				
				                color_black : "#4c4c4c",
				
				                color_white : "#fff",
				
				                color_yellow : "#ff0",
				
				                color_orange : "#f70",
				
				                color_text : "#4c4c4c",
				
				                color_grayscale : "#4c4c4c",
				
				                color_grayscale0 : "#747474",
				
				                color_grayscale1 : "#888",
				
				                color_grayscale2 : "#c4c4c4",
				
				                color_grayscale3 : "#e2e2e2",
				
				                color_grayscale4 : "#f5f5f5",
				
				                color_grayscale5 : "#d6d6d6",
				
				                color_tooltip : "#fff7b7",
				
				                color_tooltip_border : "#ffec51",
				
				                color_hover : "#fff8dc",
				
				                color_error : "#fff6f8",
				
				                color_placeholder : "#eee",
				
				                color_password_very_weak : "#a03",
				
				                color_password_weak : "#f5ac00",
				
				                color_password_good : "#69c",
				
				                color_password_strong : "green",
				
						color_000 : "black"
	};
