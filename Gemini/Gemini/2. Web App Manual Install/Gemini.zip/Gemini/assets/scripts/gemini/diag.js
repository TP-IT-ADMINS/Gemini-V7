gemini_diag = {
    log: function (data) {
        return;
        window.console && console.warn(data);
    }
};
