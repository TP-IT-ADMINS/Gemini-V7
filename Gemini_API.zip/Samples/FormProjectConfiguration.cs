﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormProjectConfiguration : Form
    {
        private ServiceManager login;

        public FormProjectConfiguration(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormProjectConfiguration_Load(object sender, EventArgs e)
        {
            try
            {
                //  BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgProjectConfiguration.DataSource = new List<GlobalConfigurationWidgetData>() { login.Widget.GetProjectConfiguration(txtAppId.Text, ((int)numProjectID.Value))};
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            GlobalConfigurationWidgetData data = login.Widget.GetProjectConfiguration(txtAppId.Text, ((int)numProjectID.Value));
            if (data.Id > 0)
            {
                txtValue.Text = data.Value;
            }
            BindGrid();
        }
    }
}
