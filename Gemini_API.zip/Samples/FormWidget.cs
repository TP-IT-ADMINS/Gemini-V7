﻿using Countersoft.Gemini.Api;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormWidget : Form
    {
        private ServiceManager login;

        public FormWidget(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormWidget_Load(object sender, EventArgs e)
        {

        }

        private void btnGlobalConfiguration_Click(object sender, EventArgs e)
        {
            FormGlobalConfiguration frm = new FormGlobalConfiguration(login);
            frm.Show();
        }

        private void btnProjectConfiguration_Click(object sender, EventArgs e)
        {
            FormProjectConfiguration frm = new FormProjectConfiguration(login);
            frm.Show();
        }

        private void btnItemWidgetData_Click(object sender, EventArgs e)
        {
            FormItemWidgetData frm = new FormItemWidgetData(login);
            frm.Show();
        }
    }
}
