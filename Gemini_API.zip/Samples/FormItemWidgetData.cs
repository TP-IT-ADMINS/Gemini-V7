﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormItemWidgetData : Form
    {
        private ServiceManager login;

        public FormItemWidgetData(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormItemWidgetData_Load(object sender, EventArgs e)
        {
            try
            {
              //  BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgItemWidgetData.DataSource = new List<IssueWidgetData>() { login.Widget.GetItemWidgetData(txtAppId.Text, txtControlID.Text, ((int)numIssueID.Value))};
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            IssueWidgetData data = login.Widget.GetItemWidgetData(txtAppId.Text, txtControlID.Text, ((int)numIssueID.Value));
            if (data.Id > 0)
            {
                txtValue.Text = data.Value;
            }

            BindGrid();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            IssueWidgetData data = login.Widget.GetItemWidgetData(txtAppId.Text, txtControlID.Text, ((int)numIssueID.Value));

            if (data.Id > 0)
            {
                data.Value = txtValue.Text;

                login.Widget.SaveItemWidgetData(data);

                BindGrid();
            }
        }
    }
}
