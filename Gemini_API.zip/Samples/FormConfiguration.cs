﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Countersoft.Gemini.TestApi
{
    public partial class FormConfiguration : Form
    {
        private ServiceManager login;

        public FormConfiguration(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormConfiguration_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgConfig.DataSource = new List<GeminiConfiguration>() { login.Admin.GetConfiguration()};
        }
    }
}
