﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Meta;

namespace Test
{
    public partial class FormResolution : Form
    {
        private ServiceManager login;

        public FormResolution(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormResolution_Load(object sender, EventArgs e)
        {
            try
            {
               BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the resolution.
            // Note that this might throw a security exception.

            dgResolution.DataSource = login.Meta.GetIssueResolutions().Select(p => p.Entity).ToList();

        }

        private void BindGrid2()
        {
            // Get all the Templates.
            // Note that this might throw a security exception.

            dgResolution.DataSource = login.Meta.GetByTemplateResolution(templateId).Select(p => p.Entity).ToList();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            IssueResolution data = login.Meta.GetIssueResolution((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Label = txtTitleDesc.Text;
                data.Entity.TemplateId = Convert.ToInt32(numTempId.Value);


                login.Meta.UpdateIssueResolution(data.Entity);

                BindGrid();
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            IssueResolution data = login.Meta.GetIssueResolution((int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtTitleDesc.Text = data.Entity.Label;
                numTempId.Value = data.Entity.TemplateId;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Resolution will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Meta.DeleteIssueResolution((int)numID.Value);
                BindGrid();
            }
        }

        private void btnCreateResolution_Click(object sender, EventArgs e)
        {
            var resolution = new IssueResolution();

            resolution.Label = txtTitleDesc.Text;
            resolution.TemplateId = Convert.ToInt32(numTempId.Value);

            login.Meta.CreateIssueResolution(resolution);

            BindGrid();
        }

        public int templateId { get; set; }

        private void numTempId_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numTempId.Value);
            BindGrid2();
        }
    }
}
