﻿namespace Test
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.btnItemProxy = new System.Windows.Forms.Button();
            this.btnCustomFieldProxy = new System.Windows.Forms.Button();
            this.btnComponentProxy = new System.Windows.Forms.Button();
            this.btnVersionProxy = new System.Windows.Forms.Button();
            this.btnAuthProxy = new System.Windows.Forms.Button();
            this.btnProjectProxy = new System.Windows.Forms.Button();
            this.btnCommentProxy = new System.Windows.Forms.Button();
            this.btnSourceControlProxy = new System.Windows.Forms.Button();
            this.btnAttchmentProxy = new System.Windows.Forms.Button();
            this.btnWatcherProxy = new System.Windows.Forms.Button();
            this.btnTimeProxy = new System.Windows.Forms.Button();
            this.btnMeta = new System.Windows.Forms.Button();
            this.btnTemplate = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnAdmin = new System.Windows.Forms.Button();
            this.btnGroup = new System.Windows.Forms.Button();
            this.btnRoadMap = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.btnChangelog = new System.Windows.Forms.Button();
            this.btnDependency = new System.Windows.Forms.Button();
            this.btnLink = new System.Windows.Forms.Button();
            this.btnNavigationCards = new System.Windows.Forms.Button();
            this.btnWidget = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnOrganizations = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnItemProxy
            // 
            this.btnItemProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnItemProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemProxy.Location = new System.Drawing.Point(360, 12);
            this.btnItemProxy.Name = "btnItemProxy";
            this.btnItemProxy.Size = new System.Drawing.Size(168, 40);
            this.btnItemProxy.TabIndex = 12;
            this.btnItemProxy.Text = "Item";
            this.btnItemProxy.Click += new System.EventHandler(this.btnIssueProxy_Click);
            // 
            // btnCustomFieldProxy
            // 
            this.btnCustomFieldProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCustomFieldProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomFieldProxy.Location = new System.Drawing.Point(360, 288);
            this.btnCustomFieldProxy.Name = "btnCustomFieldProxy";
            this.btnCustomFieldProxy.Size = new System.Drawing.Size(168, 40);
            this.btnCustomFieldProxy.TabIndex = 11;
            this.btnCustomFieldProxy.Text = "Custom Field";
            this.btnCustomFieldProxy.Click += new System.EventHandler(this.btnCustomFieldProxy_Click);
            // 
            // btnComponentProxy
            // 
            this.btnComponentProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnComponentProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComponentProxy.Location = new System.Drawing.Point(186, 104);
            this.btnComponentProxy.Name = "btnComponentProxy";
            this.btnComponentProxy.Size = new System.Drawing.Size(168, 40);
            this.btnComponentProxy.TabIndex = 10;
            this.btnComponentProxy.Text = "Component";
            this.btnComponentProxy.Click += new System.EventHandler(this.btnComponentProxy_Click);
            // 
            // btnVersionProxy
            // 
            this.btnVersionProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnVersionProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVersionProxy.Location = new System.Drawing.Point(186, 58);
            this.btnVersionProxy.Name = "btnVersionProxy";
            this.btnVersionProxy.Size = new System.Drawing.Size(168, 40);
            this.btnVersionProxy.TabIndex = 9;
            this.btnVersionProxy.Text = "Version";
            this.btnVersionProxy.Click += new System.EventHandler(this.btnVersionProxy_Click);
            // 
            // btnAuthProxy
            // 
            this.btnAuthProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAuthProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAuthProxy.Location = new System.Drawing.Point(12, 12);
            this.btnAuthProxy.Name = "btnAuthProxy";
            this.btnAuthProxy.Size = new System.Drawing.Size(168, 40);
            this.btnAuthProxy.TabIndex = 8;
            this.btnAuthProxy.Text = "Authentication";
            this.btnAuthProxy.Click += new System.EventHandler(this.btnAuthProxy_Click);
            // 
            // btnProjectProxy
            // 
            this.btnProjectProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnProjectProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectProxy.Location = new System.Drawing.Point(186, 12);
            this.btnProjectProxy.Name = "btnProjectProxy";
            this.btnProjectProxy.Size = new System.Drawing.Size(168, 40);
            this.btnProjectProxy.TabIndex = 7;
            this.btnProjectProxy.Text = "Project";
            this.btnProjectProxy.Click += new System.EventHandler(this.btnProjectProxy_Click);
            // 
            // btnCommentProxy
            // 
            this.btnCommentProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCommentProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCommentProxy.Location = new System.Drawing.Point(360, 58);
            this.btnCommentProxy.Name = "btnCommentProxy";
            this.btnCommentProxy.Size = new System.Drawing.Size(168, 40);
            this.btnCommentProxy.TabIndex = 13;
            this.btnCommentProxy.Text = "Comment";
            this.btnCommentProxy.Click += new System.EventHandler(this.btnCommentProxy_Click);
            // 
            // btnSourceControlProxy
            // 
            this.btnSourceControlProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSourceControlProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSourceControlProxy.Location = new System.Drawing.Point(360, 104);
            this.btnSourceControlProxy.Name = "btnSourceControlProxy";
            this.btnSourceControlProxy.Size = new System.Drawing.Size(168, 40);
            this.btnSourceControlProxy.TabIndex = 14;
            this.btnSourceControlProxy.Text = "Source Control";
            this.btnSourceControlProxy.Click += new System.EventHandler(this.btnSourceControlProxy_Click);
            // 
            // btnAttchmentProxy
            // 
            this.btnAttchmentProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAttchmentProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttchmentProxy.Location = new System.Drawing.Point(360, 242);
            this.btnAttchmentProxy.Name = "btnAttchmentProxy";
            this.btnAttchmentProxy.Size = new System.Drawing.Size(168, 40);
            this.btnAttchmentProxy.TabIndex = 15;
            this.btnAttchmentProxy.Text = "Attachment";
            this.btnAttchmentProxy.Click += new System.EventHandler(this.btnAttchmentProxy_Click);
            // 
            // btnWatcherProxy
            // 
            this.btnWatcherProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnWatcherProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWatcherProxy.Location = new System.Drawing.Point(360, 196);
            this.btnWatcherProxy.Name = "btnWatcherProxy";
            this.btnWatcherProxy.Size = new System.Drawing.Size(168, 40);
            this.btnWatcherProxy.TabIndex = 16;
            this.btnWatcherProxy.Text = "Watcher";
            this.btnWatcherProxy.Click += new System.EventHandler(this.btnWatcherProxy_Click);
            // 
            // btnTimeProxy
            // 
            this.btnTimeProxy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTimeProxy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimeProxy.Location = new System.Drawing.Point(360, 150);
            this.btnTimeProxy.Name = "btnTimeProxy";
            this.btnTimeProxy.Size = new System.Drawing.Size(168, 40);
            this.btnTimeProxy.TabIndex = 17;
            this.btnTimeProxy.Text = "Time";
            this.btnTimeProxy.Click += new System.EventHandler(this.btnTimeProxy_Click);
            // 
            // btnMeta
            // 
            this.btnMeta.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMeta.Location = new System.Drawing.Point(534, 150);
            this.btnMeta.Name = "btnMeta";
            this.btnMeta.Size = new System.Drawing.Size(168, 40);
            this.btnMeta.TabIndex = 18;
            this.btnMeta.Text = "Meta";
            this.btnMeta.Click += new System.EventHandler(this.btnMeta_Click);
            // 
            // btnTemplate
            // 
            this.btnTemplate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTemplate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTemplate.Location = new System.Drawing.Point(534, 334);
            this.btnTemplate.Name = "btnTemplate";
            this.btnTemplate.Size = new System.Drawing.Size(168, 40);
            this.btnTemplate.TabIndex = 19;
            this.btnTemplate.Text = "Template";
            this.btnTemplate.Click += new System.EventHandler(this.btnTemplate_Click_1);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnAdmin
            // 
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.Location = new System.Drawing.Point(534, 196);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Size = new System.Drawing.Size(168, 40);
            this.btnAdmin.TabIndex = 20;
            this.btnAdmin.Text = "Admin";
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            // 
            // btnGroup
            // 
            this.btnGroup.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGroup.Location = new System.Drawing.Point(534, 242);
            this.btnGroup.Name = "btnGroup";
            this.btnGroup.Size = new System.Drawing.Size(168, 40);
            this.btnGroup.TabIndex = 22;
            this.btnGroup.Text = "Group";
            this.btnGroup.Click += new System.EventHandler(this.btnGroup_Click);
            // 
            // btnRoadMap
            // 
            this.btnRoadMap.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRoadMap.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoadMap.Location = new System.Drawing.Point(360, 334);
            this.btnRoadMap.Name = "btnRoadMap";
            this.btnRoadMap.Size = new System.Drawing.Size(168, 40);
            this.btnRoadMap.TabIndex = 23;
            this.btnRoadMap.Text = "RoadMap";
            this.btnRoadMap.Click += new System.EventHandler(this.btnRoadMap_Click);
            // 
            // btnHistory
            // 
            this.btnHistory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistory.Location = new System.Drawing.Point(360, 426);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(168, 40);
            this.btnHistory.TabIndex = 24;
            this.btnHistory.Text = "History";
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // btnChangelog
            // 
            this.btnChangelog.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChangelog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangelog.Location = new System.Drawing.Point(360, 380);
            this.btnChangelog.Name = "btnChangelog";
            this.btnChangelog.Size = new System.Drawing.Size(168, 40);
            this.btnChangelog.TabIndex = 25;
            this.btnChangelog.Text = "Changelog";
            this.btnChangelog.Click += new System.EventHandler(this.btnChangelog_Click);
            // 
            // btnDependency
            // 
            this.btnDependency.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDependency.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDependency.Location = new System.Drawing.Point(534, 12);
            this.btnDependency.Name = "btnDependency";
            this.btnDependency.Size = new System.Drawing.Size(168, 40);
            this.btnDependency.TabIndex = 26;
            this.btnDependency.Text = "Dependency";
            this.btnDependency.Click += new System.EventHandler(this.btnDependency_Click);
            // 
            // btnLink
            // 
            this.btnLink.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLink.Location = new System.Drawing.Point(534, 58);
            this.btnLink.Name = "btnLink";
            this.btnLink.Size = new System.Drawing.Size(168, 40);
            this.btnLink.TabIndex = 27;
            this.btnLink.Text = "Link";
            this.btnLink.Click += new System.EventHandler(this.btnLink_Click);
            // 
            // btnNavigationCards
            // 
            this.btnNavigationCards.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNavigationCards.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNavigationCards.Location = new System.Drawing.Point(534, 380);
            this.btnNavigationCards.Name = "btnNavigationCards";
            this.btnNavigationCards.Size = new System.Drawing.Size(168, 40);
            this.btnNavigationCards.TabIndex = 28;
            this.btnNavigationCards.Text = "Navigation Cards";
            this.btnNavigationCards.Click += new System.EventHandler(this.btnNavigationCards_Click);
            // 
            // btnWidget
            // 
            this.btnWidget.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnWidget.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWidget.Location = new System.Drawing.Point(534, 288);
            this.btnWidget.Name = "btnWidget";
            this.btnWidget.Size = new System.Drawing.Size(168, 40);
            this.btnWidget.TabIndex = 29;
            this.btnWidget.Text = "Widget";
            this.btnWidget.Click += new System.EventHandler(this.btnWidget_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(12, 464);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(56, 13);
            this.lblVersion.TabIndex = 30;
            this.lblVersion.Text = "VersionNo";
            // 
            // btnOrganizations
            // 
            this.btnOrganizations.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnOrganizations.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrganizations.Location = new System.Drawing.Point(534, 426);
            this.btnOrganizations.Name = "btnOrganizations";
            this.btnOrganizations.Size = new System.Drawing.Size(168, 40);
            this.btnOrganizations.TabIndex = 31;
            this.btnOrganizations.Text = "Organizations";
            this.btnOrganizations.Click += new System.EventHandler(this.btnOrganizations_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 486);
            this.Controls.Add(this.btnOrganizations);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.btnWidget);
            this.Controls.Add(this.btnNavigationCards);
            this.Controls.Add(this.btnLink);
            this.Controls.Add(this.btnDependency);
            this.Controls.Add(this.btnChangelog);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.btnRoadMap);
            this.Controls.Add(this.btnGroup);
            this.Controls.Add(this.btnAdmin);
            this.Controls.Add(this.btnTemplate);
            this.Controls.Add(this.btnMeta);
            this.Controls.Add(this.btnTimeProxy);
            this.Controls.Add(this.btnWatcherProxy);
            this.Controls.Add(this.btnAttchmentProxy);
            this.Controls.Add(this.btnSourceControlProxy);
            this.Controls.Add(this.btnCommentProxy);
            this.Controls.Add(this.btnItemProxy);
            this.Controls.Add(this.btnCustomFieldProxy);
            this.Controls.Add(this.btnComponentProxy);
            this.Controls.Add(this.btnVersionProxy);
            this.Controls.Add(this.btnAuthProxy);
            this.Controls.Add(this.btnProjectProxy);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Countersoft Gemini Services";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnItemProxy;
        private System.Windows.Forms.Button btnCustomFieldProxy;
        private System.Windows.Forms.Button btnComponentProxy;
        private System.Windows.Forms.Button btnVersionProxy;
        private System.Windows.Forms.Button btnAuthProxy;
        private System.Windows.Forms.Button btnProjectProxy;
        private System.Windows.Forms.Button btnCommentProxy;
        private System.Windows.Forms.Button btnSourceControlProxy;
        private System.Windows.Forms.Button btnAttchmentProxy;
        private System.Windows.Forms.Button btnWatcherProxy;
        private System.Windows.Forms.Button btnTimeProxy;
        private System.Windows.Forms.Button btnMeta;
        private System.Windows.Forms.Button btnTemplate;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Button btnGroup;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Button btnRoadMap;
        private System.Windows.Forms.Button btnNavigationCards;
        private System.Windows.Forms.Button btnLink;
        private System.Windows.Forms.Button btnDependency;
        private System.Windows.Forms.Button btnChangelog;
        private System.Windows.Forms.Button btnWidget;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnOrganizations;
    }
}