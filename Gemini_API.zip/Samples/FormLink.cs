﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormLink : Form
    {
        private ServiceManager login;

        public FormLink(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormLink_Load(object sender, EventArgs e)
        {
            try
            {
                //BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgLink.DataSource = login.Item.GetLinks(id).ToList();

        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            List<IssueLinkDto> data = login.Item.GetLinks((int)numID.Value);

            BindGrid();
        }

        public int id { get; set; }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var links = new IssueLink();

            links.IssueId = Convert.ToInt32(numIssueID.Value);
            links.LinkTypeId = Convert.ToInt32(numLInkTypeID.Value);

            login.Item.CreateLink(links);
        }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
            id = Convert.ToInt32(numID.Value);
            BindGrid();
        }
    }
}
