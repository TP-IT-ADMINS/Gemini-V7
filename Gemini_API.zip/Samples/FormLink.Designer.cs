﻿namespace Test
{
    partial class FormLink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLink));
            this.dgLink = new System.Windows.Forms.DataGrid();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.btnGet = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.numIssueID = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numLInkTypeID = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dgLink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLInkTypeID)).BeginInit();
            this.SuspendLayout();
            // 
            // dgLink
            // 
            this.dgLink.DataMember = "";
            this.dgLink.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgLink.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgLink.Location = new System.Drawing.Point(0, 0);
            this.dgLink.Name = "dgLink";
            this.dgLink.ReadOnly = true;
            this.dgLink.Size = new System.Drawing.Size(696, 264);
            this.dgLink.TabIndex = 38;
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(364, 456);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 59;
            this.numID.ValueChanged += new System.EventHandler(this.numID_ValueChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(245, 458);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 58;
            this.label6.Text = "Link ID:";
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(270, 525);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 23);
            this.btnGet.TabIndex = 57;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(373, 525);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 60;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // numIssueID
            // 
            this.numIssueID.Location = new System.Drawing.Point(364, 412);
            this.numIssueID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numIssueID.Name = "numIssueID";
            this.numIssueID.Size = new System.Drawing.Size(100, 20);
            this.numIssueID.TabIndex = 61;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(245, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 62;
            this.label1.Text = "Issue ID:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(245, 435);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 64;
            this.label2.Text = "Link Type ID:";
            // 
            // numLInkTypeID
            // 
            this.numLInkTypeID.Location = new System.Drawing.Point(364, 435);
            this.numLInkTypeID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numLInkTypeID.Name = "numLInkTypeID";
            this.numLInkTypeID.Size = new System.Drawing.Size(100, 20);
            this.numLInkTypeID.TabIndex = 63;
            // 
            // FormLink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numLInkTypeID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numIssueID);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.dgLink);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormLink";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Link";
            this.Load += new System.EventHandler(this.FormLink_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgLink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLInkTypeID)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgLink;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.NumericUpDown numIssueID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numLInkTypeID;
    }
}