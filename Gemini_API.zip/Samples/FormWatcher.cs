﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;

namespace Test
{
    public partial class FormWatcher : Form
    {
        private ServiceManager login;

        public FormWatcher(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormWatcher_Load(object sender, EventArgs e)
        {
            try
            {
                //BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid(List<IssueWatcherDto> data)
        {
            // Get all the Watchers.
            // Note that this might throw a security exception.
            dgWatchers.DataSource = data.Select(p => p.Entity).ToList();
        }

        private void btnGetWatcher_Click(object sender, EventArgs e)
        {
            List<IssueWatcherDto> data = login.Item.IssueWatchersGet((int)numIssueID.Value);

            BindGrid(data);

        }

        private void btnCreateWatcher_Click(object sender, EventArgs e)
        {

            login.Item.IssueWatchersCreate(Convert.ToInt32(numIssueID.Value), Convert.ToInt32(numUserID.Value));
            BindGrid(login.Item.IssueWatchersGet((int)numIssueID.Value));

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int issueId = (int)numIssueID.Value;
            int userId = (int) numUserID.Value;
            if (userId <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The watcher will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.IssueWatchersDelete(issueId, userId);
                BindGrid(login.Item.IssueWatchersGet((int)numIssueID.Value));
            }
        }

        public int id { get; set; }

        private void numIssueID_ValueChanged(object sender, EventArgs e)
        {

        }

    }
}
