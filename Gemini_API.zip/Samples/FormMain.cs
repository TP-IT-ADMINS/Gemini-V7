﻿using Countersoft.Gemini.Api;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.TestApi;

namespace Test
{
    public partial class FormMain : Form
    {

        private ServiceManager login;

        public FormMain(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnAuthProxy_Click(object sender, EventArgs e)
        {
            FormAuth frm = new FormAuth(login);
            frm.Show();
        }

        private void btnProjectProxy_Click(object sender, EventArgs e)
        {
            FormProject frm = new FormProject(login);
            frm.Show();
        }

        private void btnVersionProxy_Click(object sender, EventArgs e)
        {
            FormVersion frm = new FormVersion(login);
            frm.Show();
        }

        private void btnComponentProxy_Click(object sender, EventArgs e)
        {
            FormComponent frm = new FormComponent(login);
            frm.Show();
        }

        private void btnCustomFieldProxy_Click(object sender, EventArgs e)
        {
            FormCustomField frm = new FormCustomField(login);
            frm.Show();
        }

        private void btnIssueProxy_Click(object sender, EventArgs e)
        {
            FormItem frm = new FormItem(login);
            frm.Show();
        }

        private void btnCommentProxy_Click(object sender, EventArgs e)
        {
            FormComment frm = new FormComment(login);
            frm.Show();
        }

        private void btnSourceControlProxy_Click(object sender, EventArgs e)
        {
            FormSourceControl frm = new FormSourceControl(login);
            frm.Show();
        }

        private void btnTimeProxy_Click(object sender, EventArgs e)
        {
            FormTime frm = new FormTime(login);
            frm.Show();
        }

        private void btnWatcherProxy_Click(object sender, EventArgs e)
        {
            FormWatcher frm = new FormWatcher(login);
            frm.Show();
        }

        private void btnAttchmentProxy_Click(object sender, EventArgs e)
        {
            FormAttachment frm = new FormAttachment(login);
            frm.Show();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            lblVersion.Text = string.Format("v{0}",login.Admin.GetVersion());
        }

        private void btnMeta_Click(object sender, EventArgs e)
        {
            FormMeta frm = new FormMeta(login);
            frm.Show();
        }

        private void btnTemplate_Click_1(object sender, EventArgs e)
        {
            FormTemplate frm = new FormTemplate(login);
            frm.Show();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            FormAdmin frm = new FormAdmin(login);
            frm.Show();
        }

        private void btnGroup_Click(object sender, EventArgs e)
        {
            FormGroups frm = new FormGroups(login);
            frm.Show();
        }

        private void btnRoadMap_Click(object sender, EventArgs e)
        {
            FormRoadMap frm = new FormRoadMap(login);
            frm.Show();
        }

        private void btnChangelog_Click(object sender, EventArgs e)
        {
            FormChangelog frm = new FormChangelog(login);
            frm.Show();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            FormHistory frm = new FormHistory(login);
            frm.Show();
        }

        private void btnDependency_Click(object sender, EventArgs e)
        {
            FormDependency frm = new FormDependency(login);
            frm.Show();
        }

        private void btnLink_Click(object sender, EventArgs e)
        {
            FormLink frm = new FormLink(login);
            frm.Show();
        }

        private void btnNavigationCards_Click(object sender, EventArgs e)
        {
            FormNavigationCards frm = new FormNavigationCards(login);
            frm.Show();
        }

        private void btnWidget_Click(object sender, EventArgs e)
        {
            FormWidget frm = new FormWidget(login);
            frm.Show();
        }

        private void btnOrganizations_Click(object sender, EventArgs e)
        {
            FormOrganizationsMenu frm = new FormOrganizationsMenu(login);
            frm.Show();
        }
    }
}
