﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormGlobalConfiguration : Form
    {
        private ServiceManager login;

        public FormGlobalConfiguration(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormGlobalConfiguration_Load(object sender, EventArgs e)
        {
            try
            {
              //  BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgGlobalConfiguration.DataSource = new List<GlobalConfigurationWidgetData>(){ login.Widget.GetGlobalConfiguration(txtAppId.Text) };
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            GlobalConfigurationWidgetData data = login.Widget.GetGlobalConfiguration(txtAppId.Text);
            if (data.Id > 0)
            {
                txtValue.Text = data.Value;
            }
            BindGrid();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            GlobalConfigurationWidgetData data = login.Widget.GetGlobalConfiguration(txtAppId.Text);
            if (data.Id > 0)
            {
                data.Value = txtValue.Text;

                login.Widget.SaveGlobalConfiguration(data);

                BindGrid();
            }
        }
    }
}
