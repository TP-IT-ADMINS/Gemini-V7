﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormAttachment : Form
    {
        private ServiceManager login;

        public FormAttachment(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormAttachment_Load(object sender, EventArgs e)
        {

        try
			{
				//BindGrid();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this,ex.Message);
				Close();
			}
		}

		private void BindGrid()
		{
			// Get all the Attachments.
            // Note that this might throw a security exception.

            dgAttachments.DataSource = login.Item.IssueAttachmentsGet(issueId).Select(p => p.Entity).ToList();

		}

        private void btnCreateAttachment_Click(object sender, EventArgs e)
        {
            var attachments = new IssueAttachment();

            attachments.Name = txtName.Text;
            attachments.IssueId = Convert.ToInt32(numIssueID.Value);
            attachments.ProjectId = Convert.ToInt32(numProjectID.Value);

            login.Item.IssueAttachmentCreate(attachments);

            BindGrid();
        }

        private void btnGetAttachment_Click(object sender, EventArgs e)
        {
            IssueAttachmentDto data = login.Item.IssueAttachmentGet((int)numIssueID.Value, (int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtName.Text = data.Entity.Name;
                numIssueID.Value = data.Entity.IssueId;
                numProjectID.Value = data.Entity.ProjectId;

                BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The attachment will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.IssueAttachmentDelete((int)numIssueID.Value, id);
                BindGrid();
            }

        }

        private void btnUpdateAttachment_Click(object sender, EventArgs e)
        {
            IssueAttachmentDto data = login.Item.IssueAttachmentGet((int)numIssueID.Value, (int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Name = txtName.Text;
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);
                data.Entity.IssueId = Convert.ToInt32(numIssueID.Value);

                data.Entity.Id = (int)numID.Value;

                login.Item.IssueAttachmentUpdate(data.Entity);

                BindGrid();
            }
        }

        public int issueId { get; set; }

        private void numIssueID_ValueChanged(object sender, EventArgs e)
        {
            issueId = Convert.ToInt32(numIssueID.Value);
            BindGrid();
        }
    }
}
