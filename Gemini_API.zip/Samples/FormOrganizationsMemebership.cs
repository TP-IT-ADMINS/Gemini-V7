﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity.Security;

namespace Countersoft.Gemini.TestApi
{
    public partial class FormOrganizationsMemebership : Form
    {
        private ServiceManager login;

        public FormOrganizationsMemebership(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormOrganizationsMemebership_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var joinGroup = new OrganizationMembership();

            int Userid = (int)numUserID.Value;
            int OrganizationID = (int)numGroupID.Value;

            login.Groups.JoinOrganization(OrganizationID, Userid);

            BindGrid();
        }

        private void BindGrid()
        {
            dgMembership.DataSource = login.Groups.GetOrganizations().ToList();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int Userid = (int)numUserID.Value;
            int OrganizationID = (int)numGroupID.Value;

            if (Userid <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The user will remove from Organization! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Groups.LeaveOrganization(OrganizationID, Userid);
            }

            BindGrid();
        }
    }
}
