﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;

namespace Test
{
    public partial class FormLogin : Form
    {
        private ServiceManager login;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnOK_Click_1(object sender, EventArgs e)
        {
            login = new ServiceManager(txtUrl.Text, txtUserName.Text, txtPassword.Text, "", false);

            try
            {
                UserDto user = login.Admin.WhoAmI();

                // This is just for safety.
                // If we are here then we've logged in successfully.
                if (user.Entity.Id > 0)
                {
                    DialogResult = DialogResult.OK;
                    FormMain frm = new FormMain(login);
                    frm.Show();
                    return;
                }
            }
            catch
            {
                // Log in error. (password is incorrect?)
                //MessageBox.Show(ex.Message);
            }

            MessageBox.Show(this, "Invalid user name / password / URL Address");
            txtUserName.Select();
            return;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
