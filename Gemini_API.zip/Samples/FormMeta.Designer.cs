﻿namespace Test
{
    partial class FormMeta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMeta));
            this.btnType = new System.Windows.Forms.Button();
            this.btnSeverity = new System.Windows.Forms.Button();
            this.btnPriority = new System.Windows.Forms.Button();
            this.btnStatus = new System.Windows.Forms.Button();
            this.btnResolution = new System.Windows.Forms.Button();
            this.btnLinkTypes = new System.Windows.Forms.Button();
            this.btnTimeTypes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnType
            // 
            this.btnType.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnType.Location = new System.Drawing.Point(110, 31);
            this.btnType.Name = "btnType";
            this.btnType.Size = new System.Drawing.Size(168, 40);
            this.btnType.TabIndex = 12;
            this.btnType.Text = "Types";
            this.btnType.Click += new System.EventHandler(this.btnType_Click);
            // 
            // btnSeverity
            // 
            this.btnSeverity.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSeverity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeverity.Location = new System.Drawing.Point(110, 145);
            this.btnSeverity.Name = "btnSeverity";
            this.btnSeverity.Size = new System.Drawing.Size(168, 40);
            this.btnSeverity.TabIndex = 13;
            this.btnSeverity.Text = "Severity";
            this.btnSeverity.Click += new System.EventHandler(this.btnSeverity_Click);
            // 
            // btnPriority
            // 
            this.btnPriority.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPriority.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPriority.Location = new System.Drawing.Point(110, 87);
            this.btnPriority.Name = "btnPriority";
            this.btnPriority.Size = new System.Drawing.Size(168, 40);
            this.btnPriority.TabIndex = 14;
            this.btnPriority.Text = "Priority";
            this.btnPriority.Click += new System.EventHandler(this.btnPriority_Click);
            // 
            // btnStatus
            // 
            this.btnStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatus.Location = new System.Drawing.Point(110, 208);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(168, 40);
            this.btnStatus.TabIndex = 15;
            this.btnStatus.Text = "Status";
            this.btnStatus.Click += new System.EventHandler(this.btnStatus_Click);
            // 
            // btnResolution
            // 
            this.btnResolution.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnResolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResolution.Location = new System.Drawing.Point(110, 269);
            this.btnResolution.Name = "btnResolution";
            this.btnResolution.Size = new System.Drawing.Size(168, 40);
            this.btnResolution.TabIndex = 16;
            this.btnResolution.Text = "Resolution";
            this.btnResolution.Click += new System.EventHandler(this.btnResolution_Click);
            // 
            // btnLinkTypes
            // 
            this.btnLinkTypes.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLinkTypes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLinkTypes.Location = new System.Drawing.Point(110, 329);
            this.btnLinkTypes.Name = "btnLinkTypes";
            this.btnLinkTypes.Size = new System.Drawing.Size(168, 40);
            this.btnLinkTypes.TabIndex = 17;
            this.btnLinkTypes.Text = "Link Types";
            this.btnLinkTypes.Click += new System.EventHandler(this.btnLinkTypes_Click);
            // 
            // btnTimeTypes
            // 
            this.btnTimeTypes.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTimeTypes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimeTypes.Location = new System.Drawing.Point(110, 384);
            this.btnTimeTypes.Name = "btnTimeTypes";
            this.btnTimeTypes.Size = new System.Drawing.Size(168, 40);
            this.btnTimeTypes.TabIndex = 18;
            this.btnTimeTypes.Text = "Time Types";
            this.btnTimeTypes.Click += new System.EventHandler(this.btnTimeTypes_Click);
            // 
            // FormMeta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 459);
            this.Controls.Add(this.btnTimeTypes);
            this.Controls.Add(this.btnLinkTypes);
            this.Controls.Add(this.btnResolution);
            this.Controls.Add(this.btnStatus);
            this.Controls.Add(this.btnPriority);
            this.Controls.Add(this.btnSeverity);
            this.Controls.Add(this.btnType);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMeta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Meta";
            this.Load += new System.EventHandler(this.FormMeta_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnType;
        private System.Windows.Forms.Button btnSeverity;
        private System.Windows.Forms.Button btnPriority;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Button btnResolution;
        private System.Windows.Forms.Button btnLinkTypes;
        private System.Windows.Forms.Button btnTimeTypes;
    }
}