﻿namespace Test
{
    partial class FormNavigationCards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNavigationCards));
            this.dgNavigationCards = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dgNavigationCards)).BeginInit();
            this.SuspendLayout();
            // 
            // dgNavigationCards
            // 
            this.dgNavigationCards.DataMember = "";
            this.dgNavigationCards.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgNavigationCards.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgNavigationCards.Location = new System.Drawing.Point(0, 0);
            this.dgNavigationCards.Name = "dgNavigationCards";
            this.dgNavigationCards.ReadOnly = true;
            this.dgNavigationCards.Size = new System.Drawing.Size(696, 264);
            this.dgNavigationCards.TabIndex = 39;
            // 
            // FormNavigationCards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.dgNavigationCards);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormNavigationCards";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Navigation Cards";
            this.Load += new System.EventHandler(this.FormNavigationCards_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgNavigationCards)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgNavigationCards;
    }
}