﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormProjectGroups : Form
    {
        private ServiceManager login;

        public FormProjectGroups(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormProjectGroups_Load(object sender, EventArgs e)
        {

            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgProjectGroups.DataSource = login.Groups.GetProjectGroups().ToList();
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            ProjectGroup data = login.Groups.GetProjectGroup((int)numID.Value);
            if (data.Id > 0)
            {
                txtName.Text = data.Name;
                txtDescription.Text = data.Description;
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var groups = new ProjectGroup();

            groups.Description = txtDescription.Text;
            groups.Name = txtName.Text;

            login.Groups.CreateProjectGroup(groups);

            BindGrid();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ProjectGroup data = login.Groups.GetProjectGroup((int)numID.Value);

            if (data.Id > 0)
            {

                data.Description = txtDescription.Text;
                data.Name = txtName.Text;

                data.Id = Convert.ToInt32((int)numID.Value);

                // Use this to do a full user update.

                login.Groups.UpdateProjectGroup(data);

                BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The project group will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Groups.DeleteProjectGroup(id);
            }

            BindGrid();
        }
    }
}
