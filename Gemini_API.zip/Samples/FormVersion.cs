﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormVersion : Form
    {
        private ServiceManager login;

        public FormVersion(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnGetVersion_Click(object sender, EventArgs e)
        {
            VersionDto data = login.Projects.GetVersion((int)numProjectID.Value, (int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtName.Text = data.Entity.Name;
                txtDesc.Text = data.Entity.Label;
                numProjectID.Value = data.Entity.ProjectId;
            }
        }

        private void btnCreateVersion_Click(object sender, EventArgs e)
        {
            var versions = new Countersoft.Gemini.Commons.Entity.Version();

            versions.Name = txtName.Text;
            versions.Label = txtDesc.Text;
            versions.ProjectId = Convert.ToInt32(numProjectID.Value);

            login.Projects.CreateVersion(versions);

            BindGrid();

        }

        private void btnDeleteVersion_Click(object sender, EventArgs e)
        {
            int id = (int) numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (
                MessageBox.Show(this, "The version will be deleted permantly! Are you sure you want to do this?",
                                "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Projects.DeleteVersion((int)numProjectID.Value, id);
                BindGrid();
            }
        }

        private void btnUpdateVersion_Click(object sender, EventArgs e)
        {
            VersionDto data = login.Projects.GetVersion((int)numProjectID.Value, (int)numID.Value);
            if (data.Entity.Id > 0)
            {
                data.Entity.Name = txtName.Text;
                data.Entity.Label = txtDesc.Text;
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);

                data.Entity.Id = (int) numID.Value;

                login.Projects.UpdateVersion(data.Entity);


                BindGrid();
            }
        }


        private void FormVersion_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the Versions.
            // Note that this might throw a security exception.

            var projects = login.Projects.GetProjects();
            dgVersions.DataSource = login.Projects.GetVersions(projects[0].Entity.Id).Select(p => p.Entity).ToList();
        }
    }
}
