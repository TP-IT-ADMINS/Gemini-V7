﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Countersoft.Gemini.TestApi
{
    public class BaseForm:Form
    {
        public bool Execute(Func<bool> func) 
        {
            try
            {
                return func();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                Console.WriteLine(e);
                return false;
            }
        }
    }
}
