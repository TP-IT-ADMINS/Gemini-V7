﻿namespace Countersoft.Gemini.TestApi
{
    partial class FormOrganizationsMemebership
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOrganizationsMemebership));
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numGroupID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.dgMembership = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGroupID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgMembership)).BeginInit();
            this.SuspendLayout();
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(359, 471);
            this.numUserID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(148, 20);
            this.numUserID.TabIndex = 84;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(227, 473);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 23);
            this.label2.TabIndex = 83;
            this.label2.Text = "User ID:";
            // 
            // numGroupID
            // 
            this.numGroupID.Location = new System.Drawing.Point(359, 416);
            this.numGroupID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numGroupID.Name = "numGroupID";
            this.numGroupID.Size = new System.Drawing.Size(148, 20);
            this.numGroupID.TabIndex = 78;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(227, 418);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 23);
            this.label6.TabIndex = 77;
            this.label6.Text = "Organizations ID:";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(383, 536);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(110, 23);
            this.btnDelete.TabIndex = 76;
            this.btnDelete.Text = "Leave Organization";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(265, 536);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(99, 23);
            this.btnCreate.TabIndex = 75;
            this.btnCreate.Text = "Join Organization";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // dgMembership
            // 
            this.dgMembership.DataMember = "";
            this.dgMembership.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgMembership.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgMembership.Location = new System.Drawing.Point(0, 0);
            this.dgMembership.Name = "dgMembership";
            this.dgMembership.ReadOnly = true;
            this.dgMembership.Size = new System.Drawing.Size(696, 264);
            this.dgMembership.TabIndex = 74;
            // 
            // FormOrganizationsMemebership
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numGroupID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.dgMembership);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormOrganizationsMemebership";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormOrganizationsMemebership";
            this.Load += new System.EventHandler(this.FormOrganizationsMemebership_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGroupID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgMembership)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numGroupID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.DataGrid dgMembership;
    }
}