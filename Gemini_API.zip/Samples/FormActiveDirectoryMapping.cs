﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormActiveDirectoryMapping : Form
    {
        private ServiceManager login;

        public FormActiveDirectoryMapping(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }
        private void FormActiveDirectoryMapping_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgActiveDirectoryMapping.DataSource = login.Groups.GetActiveDirectoryGroupMappings().ToList(); ;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var mapping = new ActiveDirectoryGroupMapping();

            mapping.ProjectGroupId = Convert.ToInt32(numGroupID.Value);
            mapping.ADGroupId = Convert.ToInt32(numADGroupId.Value);

            login.Groups.CreateActiveDirectoryGroupMapping(mapping);

            BindGrid();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
          //  ActiveDirectoryGroupMapping data = login.Groups.GetActiveDirectoryGroupMappings
        }
    }
}
