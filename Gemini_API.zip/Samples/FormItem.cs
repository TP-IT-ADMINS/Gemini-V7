﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;
using Countersoft.Gemini.TestApi;

namespace Test
{
    public partial class FormItem : BaseForm
    {
        private ServiceManager login;

        public FormItem(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
            issueFilter = IssuesFilter.CreateProjectFilter(sm.User.WhoAmI().Entity.Id, 15);
        }

        private void btnGetIssue_Click(object sender, EventArgs e)
        {
            base.Execute(()=>
            {
                IssueDto data = login.Item.Get((int)numID.Value);
                if (data.Entity.Id > 0)
                {
                    txtDesc.Text = data.Entity.Description;
                    txtTitle.Text = data.Entity.Title;
                    numUserID.Value = data.Entity.ReportedBy;
                    numProjectID.Value = data.Entity.ProjectId;
                }

                return true;
            });
        }

        private void FormItem_Load(object sender, EventArgs e)
        {
            try
			{
				//BindGrid();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this,ex.Message);
				Close();
			}
		}

		private void BindGrid()
		{
		    // Get all the items.
            // Note that this might throw a security exception.
            dgIssues.DataSource = login.Item.GetFilteredItems(issueFilter).Select(p => p.Entity).ToList();

		   // dgIssues.DataSource = sm.Item.Get(id);

		}

        private void btnCreateItem_Click(object sender, EventArgs e)
        {
            var items = new Issue();

            items.Description = txtDesc.Text;
            items.Title = txtTitle.Text;
            items.ProjectId = Convert.ToInt32(numProjectID.Value);
            items.ReportedBy = Convert.ToInt32(numUserID.Value);
            items.OrganizationId = Convert.ToInt32(OrganizationId.Value);
            if (items.OrganizationId == 0) items.OrganizationId = null;


            login.Item.Create(items);
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The item will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.Delete(id);
                BindGrid();
            }
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            IssueDto data = login.Item.Get((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Title = txtTitle.Text;
                data.Entity.Description = txtDesc.Text;
                data.Entity.ReportedBy = Convert.ToInt32(numUserID.Value);
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);

                data.Entity.Id = (int)numID.Value;

                login.Item.Update(data.Entity);

                BindGrid();
            }
        }

        public IssuesFilter issueFilter { get; set; }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
          //  id = Convert.ToInt32(numID.Value);
           // BindGrid();
        }

        private void numProjectID_ValueChanged(object sender, EventArgs e)
        {
            Execute(() =>
            {
                issueFilter = IssuesFilter.CreateProjectFilter(login.User.WhoAmI().Entity.Id,
                    Convert.ToInt32(numProjectID.Value));
                BindGrid();
                return true;
            });
        }
    }
}
