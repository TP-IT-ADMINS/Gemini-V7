﻿namespace Test
{
    partial class FormGlobalConfiguration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGlobalConfiguration));
            this.dgGlobalConfiguration = new System.Windows.Forms.DataGrid();
            this.label6 = new System.Windows.Forms.Label();
            this.btnGet = new System.Windows.Forms.Button();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgGlobalConfiguration)).BeginInit();
            this.SuspendLayout();
            // 
            // dgGlobalConfiguration
            // 
            this.dgGlobalConfiguration.DataMember = "";
            this.dgGlobalConfiguration.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgGlobalConfiguration.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgGlobalConfiguration.Location = new System.Drawing.Point(0, 0);
            this.dgGlobalConfiguration.Name = "dgGlobalConfiguration";
            this.dgGlobalConfiguration.ReadOnly = true;
            this.dgGlobalConfiguration.Size = new System.Drawing.Size(696, 264);
            this.dgGlobalConfiguration.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(204, 483);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 23);
            this.label6.TabIndex = 70;
            this.label6.Text = "App ID:";
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(281, 520);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 23);
            this.btnGet.TabIndex = 72;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // txtAppId
            // 
            this.txtAppId.Location = new System.Drawing.Point(289, 480);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.Size = new System.Drawing.Size(242, 20);
            this.txtAppId.TabIndex = 73;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(362, 520);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 80;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(289, 454);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(242, 20);
            this.txtValue.TabIndex = 82;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(204, 457);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 23);
            this.label1.TabIndex = 81;
            this.label1.Text = "Value:";
            // 
            // FormGlobalConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtAppId);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgGlobalConfiguration);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormGlobalConfiguration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Global Configuration";
            this.Load += new System.EventHandler(this.FormGlobalConfiguration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgGlobalConfiguration)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGrid dgGlobalConfiguration;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.TextBox txtAppId;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.Label label1;
    }
}