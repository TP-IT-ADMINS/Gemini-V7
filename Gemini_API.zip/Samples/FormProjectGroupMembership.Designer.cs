﻿namespace Test
{
    partial class FormProjectGroupMembership
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProjectGroupMembership));
            this.dgProjectGroupsMembership = new System.Windows.Forms.DataGrid();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCreate = new System.Windows.Forms.Button();
            this.numGroupID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.btnLeaveProject = new System.Windows.Forms.Button();
            this.btnJoinProject = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectGroupsMembership)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGroupID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            this.SuspendLayout();
            // 
            // dgProjectGroupsMembership
            // 
            this.dgProjectGroupsMembership.DataMember = "";
            this.dgProjectGroupsMembership.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgProjectGroupsMembership.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgProjectGroupsMembership.Location = new System.Drawing.Point(0, 0);
            this.dgProjectGroupsMembership.Name = "dgProjectGroupsMembership";
            this.dgProjectGroupsMembership.ReadOnly = true;
            this.dgProjectGroupsMembership.Size = new System.Drawing.Size(696, 264);
            this.dgProjectGroupsMembership.TabIndex = 37;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(273, 527);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(77, 23);
            this.btnDelete.TabIndex = 65;
            this.btnDelete.Text = "Leave Group";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(192, 527);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 64;
            this.btnCreate.Text = "Join Group";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // numGroupID
            // 
            this.numGroupID.Location = new System.Drawing.Point(359, 400);
            this.numGroupID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numGroupID.Name = "numGroupID";
            this.numGroupID.Size = new System.Drawing.Size(148, 20);
            this.numGroupID.TabIndex = 67;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(227, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 23);
            this.label6.TabIndex = 66;
            this.label6.Text = "Project Group ID:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(227, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 23);
            this.label1.TabIndex = 68;
            this.label1.Text = "Project ID:";
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(359, 440);
            this.numProjectID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(148, 20);
            this.numProjectID.TabIndex = 69;
            // 
            // btnLeaveProject
            // 
            this.btnLeaveProject.Location = new System.Drawing.Point(473, 527);
            this.btnLeaveProject.Name = "btnLeaveProject";
            this.btnLeaveProject.Size = new System.Drawing.Size(95, 23);
            this.btnLeaveProject.TabIndex = 71;
            this.btnLeaveProject.Text = "Leave Project";
            this.btnLeaveProject.UseVisualStyleBackColor = true;
            this.btnLeaveProject.Click += new System.EventHandler(this.btnLeaveProject_Click);
            // 
            // btnJoinProject
            // 
            this.btnJoinProject.Location = new System.Drawing.Point(374, 527);
            this.btnJoinProject.Name = "btnJoinProject";
            this.btnJoinProject.Size = new System.Drawing.Size(93, 23);
            this.btnJoinProject.TabIndex = 70;
            this.btnJoinProject.Text = "Join Project";
            this.btnJoinProject.UseVisualStyleBackColor = true;
            this.btnJoinProject.Click += new System.EventHandler(this.btnJoinProject_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(227, 477);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 23);
            this.label2.TabIndex = 72;
            this.label2.Text = "User ID:";
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(359, 475);
            this.numUserID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(148, 20);
            this.numUserID.TabIndex = 73;
            // 
            // FormProjectGroupMembership
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLeaveProject);
            this.Controls.Add(this.btnJoinProject);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numGroupID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.dgProjectGroupsMembership);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormProjectGroupMembership";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Group Membership";
            this.Load += new System.EventHandler(this.FormProjectGroupMembership_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectGroupsMembership)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGroupID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgProjectGroupsMembership;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.NumericUpDown numGroupID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Button btnLeaveProject;
        private System.Windows.Forms.Button btnJoinProject;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numUserID;
    }
}