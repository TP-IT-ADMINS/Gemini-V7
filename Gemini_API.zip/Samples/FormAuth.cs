﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormAuth : Form
    {
        private ServiceManager login;

        public FormAuth(ServiceManager sm)
        {
            InitializeComponent();
            login = sm;
        }

        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            var users = new User();
            
            users.Username = txtUserName.Text;
            users.Firstname = txtFirstName.Text;
            users.Surname = txtLastName.Text;
            users.Email = txtEmail.Text;

            login.User.CreateUser(users);

            BindGrid();
        }

        private void FormAuth_Load(object sender, EventArgs e)
        {
            try
			{
				BindGrid();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this,ex.Message);
				Close();
			}
		}

		private void BindGrid()
		{
			// Get all the users.
            // Note that this might throw a security exception.
            dgUsers.DataSource = login.User.GetUsers().Select(p => p.Entity).ToList();

		}

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            UserDto data = login.User.GetUser((int)numUserID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Username = txtUserName.Text;
                data.Entity.Firstname = txtFirstName.Text;
                data.Entity.Surname = txtLastName.Text;
                data.Entity.Email = txtEmail.Text;

                data.Entity.Id = Convert.ToInt32((int)numUserID.Value);

                // Use this to do a full user update.

                login.User.UpdateUser(data.Entity);

                BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numUserID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The user will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.User.DeleteUser(id);
            }

            BindGrid();
        }

        private void btnGetUser_Click(object sender, EventArgs e)
        {
            UserDto data = login.User.GetUser((int)numUserID.Value);
            if (data.Entity.Id > 0)
            {
                txtUserName.Text = data.Entity.Username;
                txtFirstName.Text = data.Entity.Firstname;
                txtLastName.Text = data.Entity.Surname;
                txtEmail.Text = data.Entity.Email;
            }
        }

        private void btnGetUsername_Click(object sender, EventArgs e)
        {
            UserDto data = login.User.GetUsername(txtUserName.Text);

            if (data.Entity.Id > 0)
            {
                txtFirstName.Text = data.Entity.Firstname;
                txtLastName.Text = data.Entity.Surname;
                txtEmail.Text = data.Entity.Email;
                numUserID.Value = data.Entity.Id;
            }
        }
    }
}
