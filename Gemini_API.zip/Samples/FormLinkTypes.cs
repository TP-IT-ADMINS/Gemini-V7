﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Meta;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormLinkTypes : Form
    {
        private ServiceManager login;

        public FormLinkTypes(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }


        private void FormLinkTypes_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgLinkTypes.DataSource = login.Meta.GetIssueLinkTypes(templateId).ToList(); ;

        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            List<IssueLinkType> data = login.Meta.GetIssueLinkTypes((int)numID.Value);

            BindGrid();
        }

        public int templateId { get; set; }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numID.Value);
            BindGrid();
        }
    }
}
