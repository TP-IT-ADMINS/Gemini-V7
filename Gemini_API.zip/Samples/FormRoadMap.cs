﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormRoadMap : Form
    {
        private ServiceManager login;

        public FormRoadMap(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormRoadMap_Load(object sender, EventArgs e)
        {
            try
            {
                BindGridVersion();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgRoadMap.DataSource = login.Item.GetRoadmap(versionId).ToList();
        }

        private void BindGridVersion()
        {
            var projects = login.Projects.GetProjects();
            dgRoadMap.DataSource = login.Projects.GetVersions(projects[0].Entity.Id).Select(p => p.Entity).ToList();
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            List<IssueDto> data = login.Item.GetRoadmap((int)numID.Value);

            BindGrid();
        }

        public int versionId { get; set; }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
            versionId = Convert.ToInt32(numID.Value);
            BindGrid();
        }
    }
}
