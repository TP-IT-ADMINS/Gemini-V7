﻿namespace Countersoft.Gemini.TestApi
{
    partial class FormOrganizationsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormOrganizationsMenu));
            this.btnOrganizationsMemebership = new System.Windows.Forms.Button();
            this.btnOrganizations = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOrganizationsMemebership
            // 
            this.btnOrganizationsMemebership.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnOrganizationsMemebership.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrganizationsMemebership.Location = new System.Drawing.Point(97, 104);
            this.btnOrganizationsMemebership.Name = "btnOrganizationsMemebership";
            this.btnOrganizationsMemebership.Size = new System.Drawing.Size(168, 40);
            this.btnOrganizationsMemebership.TabIndex = 29;
            this.btnOrganizationsMemebership.Text = "Organizations Memebership";
            this.btnOrganizationsMemebership.Click += new System.EventHandler(this.btnOrganizationsMemebership_Click);
            // 
            // btnOrganizations
            // 
            this.btnOrganizations.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnOrganizations.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrganizations.Location = new System.Drawing.Point(97, 43);
            this.btnOrganizations.Name = "btnOrganizations";
            this.btnOrganizations.Size = new System.Drawing.Size(168, 40);
            this.btnOrganizations.TabIndex = 28;
            this.btnOrganizations.Text = "Organizations";
            this.btnOrganizations.Click += new System.EventHandler(this.btnOrganizations_Click);
            // 
            // FormOrganizationsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 194);
            this.Controls.Add(this.btnOrganizationsMemebership);
            this.Controls.Add(this.btnOrganizations);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormOrganizationsMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormOrganizationsMenu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOrganizationsMemebership;
        private System.Windows.Forms.Button btnOrganizations;
    }
}