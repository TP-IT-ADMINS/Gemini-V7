﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity;
using Countersoft.Gemini.Commons.Entity.ProjectTemplates;

namespace Test
{
    public partial class FormTemplate : Form
    {
        private ServiceManager login;

        public FormTemplate(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormTemplate_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the Templates.
            // Note that this might throw a security exception.

            dgTemplates.DataSource = login.Meta.GetTemplates().Select(p => p).ToList();

        }
        public int templateId { get; set; }

        private void btnGetTemplate_Click(object sender, EventArgs e)
        {
            InstalledProjectTemplate data = login.Meta.GetTemplate((int)numID.Value);
            if (data.Id > 0)
            {
                txtTitle.Text = data.Name;
                txtKey.Text = data.TemplateKey;
                txtDesc.Text = data.Description;

                BindGrid();
            }
        }

   }
}
