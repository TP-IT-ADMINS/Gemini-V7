﻿namespace Test
{
    partial class FormSeverity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSeverity));
            this.numTempId = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdateSeverity = new System.Windows.Forms.Button();
            this.btnGetSeverity = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTitleDesc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgSeverity = new System.Windows.Forms.DataGrid();
            this.btnCreateSeverity = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numTempId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSeverity)).BeginInit();
            this.SuspendLayout();
            // 
            // numTempId
            // 
            this.numTempId.Location = new System.Drawing.Point(368, 386);
            this.numTempId.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numTempId.Name = "numTempId";
            this.numTempId.Size = new System.Drawing.Size(100, 20);
            this.numTempId.TabIndex = 76;
            this.numTempId.ValueChanged += new System.EventHandler(this.numTempId_ValueChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(248, 388);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 75;
            this.label2.Text = "Template ID:";
            // 
            // btnUpdateSeverity
            // 
            this.btnUpdateSeverity.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateSeverity.Location = new System.Drawing.Point(481, 536);
            this.btnUpdateSeverity.Name = "btnUpdateSeverity";
            this.btnUpdateSeverity.Size = new System.Drawing.Size(103, 24);
            this.btnUpdateSeverity.TabIndex = 74;
            this.btnUpdateSeverity.Text = "Update Severity";
            this.btnUpdateSeverity.Click += new System.EventHandler(this.btnUpdateSeverity_Click);
            // 
            // btnGetSeverity
            // 
            this.btnGetSeverity.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetSeverity.Location = new System.Drawing.Point(377, 536);
            this.btnGetSeverity.Name = "btnGetSeverity";
            this.btnGetSeverity.Size = new System.Drawing.Size(90, 24);
            this.btnGetSeverity.TabIndex = 73;
            this.btnGetSeverity.Text = "Get Severity";
            this.btnGetSeverity.Click += new System.EventHandler(this.btnGetSeverity_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Location = new System.Drawing.Point(264, 536);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(98, 24);
            this.btnDelete.TabIndex = 72;
            this.btnDelete.Text = "Delete Severity";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(368, 431);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 71;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(248, 433);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 70;
            this.label6.Text = "Severity ID:";
            // 
            // txtTitleDesc
            // 
            this.txtTitleDesc.Location = new System.Drawing.Point(368, 339);
            this.txtTitleDesc.Name = "txtTitleDesc";
            this.txtTitleDesc.Size = new System.Drawing.Size(184, 20);
            this.txtTitleDesc.TabIndex = 69;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 68;
            this.label1.Text = "Severity Desc:";
            // 
            // dgSeverity
            // 
            this.dgSeverity.DataMember = "";
            this.dgSeverity.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgSeverity.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgSeverity.Location = new System.Drawing.Point(0, 0);
            this.dgSeverity.Name = "dgSeverity";
            this.dgSeverity.ReadOnly = true;
            this.dgSeverity.Size = new System.Drawing.Size(696, 264);
            this.dgSeverity.TabIndex = 67;
            // 
            // btnCreateSeverity
            // 
            this.btnCreateSeverity.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateSeverity.Location = new System.Drawing.Point(151, 536);
            this.btnCreateSeverity.Name = "btnCreateSeverity";
            this.btnCreateSeverity.Size = new System.Drawing.Size(98, 24);
            this.btnCreateSeverity.TabIndex = 66;
            this.btnCreateSeverity.Text = "Create Severity";
            this.btnCreateSeverity.Click += new System.EventHandler(this.btnCreateSeverity_Click);
            // 
            // FormSeverity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numTempId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateSeverity);
            this.Controls.Add(this.btnGetSeverity);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTitleDesc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgSeverity);
            this.Controls.Add(this.btnCreateSeverity);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormSeverity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Severity";
            this.Load += new System.EventHandler(this.FormSeverity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTempId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSeverity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numTempId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdateSeverity;
        private System.Windows.Forms.Button btnGetSeverity;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTitleDesc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgSeverity;
        private System.Windows.Forms.Button btnCreateSeverity;
    }
}