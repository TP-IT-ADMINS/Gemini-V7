﻿using Countersoft.Gemini.Api;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.TestApi;

namespace Test
{
    public partial class FormGroups : Form
    {
        private ServiceManager login;

        public FormGroups(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnProjectGroups_Click(object sender, EventArgs e)
        {
            FormProjectGroups frm = new FormProjectGroups(login);
            frm.Show();
        }

        private void btnProjectGroupMembership_Click(object sender, EventArgs e)
        {
            FormProjectGroupMembership frm = new FormProjectGroupMembership(login);
            frm.Show();
        }

        private void btnActiveDirectory_Click(object sender, EventArgs e)
        {
            FormActiveDirectory frm = new FormActiveDirectory(login);
            frm.Show();
        }

        private void btnActiveDirectoryMapping_Click(object sender, EventArgs e)
        {
            FormActiveDirectoryMapping frm = new FormActiveDirectoryMapping(login);
            frm.Show();
        }

        private void btnOrganizations_Click(object sender, EventArgs e)
        {
            FormOrganizations frm = new FormOrganizations(login);
            frm.Show();
        }

        private void btnOrganizationsMemebership_Click(object sender, EventArgs e)
        {
            FormOrganizationsMemebership frm = new FormOrganizationsMemebership(login);
            frm.Show();
        }
    }
}
