﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormSourceControl : Form
    {
        private ServiceManager login;

        public FormSourceControl(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnGetControl_Click(object sender, EventArgs e)
        {
            SourceControlFile data = login.Item.GetSourceControlFile((int)numIssueID.Value, (int)numID.Value);
            if (data.Id>0)
            {
                txtName.Text = data.Name;
                txtPath.Text = data.Path;
                txtRepository.Text = data.Repository;
                numIssueID.Value = data.IssueId;
            }
        }

        private void FormSourceControl_Load(object sender, EventArgs e)
        {

            try
            {
               // BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the SourceControls.
            // Note that this might throw a security exception.
           //dgSourceControls.DataSource = sm.SourceControlFiles.GetSourceControlFile(id);

            dgSourceControls.DataSource = login.Item.GetSourceControlFiles(issueId).ToList();

        }

        private void btnCreateControl_Click(object sender, EventArgs e)
        {
            var controls = new SourceControlFile();

            controls.Name = txtName.Text;
            controls.Path = txtPath.Text;
            controls.Repository = txtRepository.Text;
            controls.IssueId = Convert.ToInt32(numIssueID.Value);

            login.Item.CreateSourceControlFile(controls);

            BindGrid();
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The source control file will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.DeleteSourceControlFile((int)numIssueID.Value, id);
                BindGrid();
            }

        }

        private void btnUpdateControl_Click(object sender, EventArgs e)
        {

            SourceControlFile data = login.Item.GetSourceControlFile((int)numIssueID.Value, (int)numID.Value);

            if (data.Id >0)
            {
                data.Name = txtName.Text;
                data.Repository = txtRepository.Text;
                data.Path = txtPath.Text;
                data.IssueId = Convert.ToInt32(numIssueID.Value);

                data.Id = (int) numID.Value;

                login.Item.UpdateSourceControlFile(data);

                BindGrid();
            }
        }


        private void numIssueID_ValueChanged(object sender, EventArgs e)
        {
            issueId = Convert.ToInt32(numIssueID.Value);
            BindGrid();
        }


        public int issueId { get; set; }

    }
}
