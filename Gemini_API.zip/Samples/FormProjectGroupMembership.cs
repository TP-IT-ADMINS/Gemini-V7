﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormProjectGroupMembership : Form
    {
        private ServiceManager login;

        public FormProjectGroupMembership(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormProjectGroupMembership_Load(object sender, EventArgs e)
        {

            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgProjectGroupsMembership.DataSource = login.Groups.GetProjectGroups().ToList(); ;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var joinGroup = new ProjectGroupMembership();
          
            int Userid = (int)numUserID.Value;
            int GroupID = (int)numGroupID.Value;

            login.Groups.JoinProjectGroup(GroupID, Userid);

            BindGrid();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int Userid = (int)numUserID.Value;
            int GroupID = (int)numGroupID.Value;

            if (Userid <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The user will remove from Group! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Groups.LeaveProjectGroup(GroupID,Userid);
            }

            BindGrid();
        }

        private void btnJoinProject_Click(object sender, EventArgs e)
        {

            int Userid = (int)numUserID.Value;
            int GroupID = (int)numGroupID.Value;
            int ProjectID = (int)numProjectID.Value;

            login.Groups.JoinProjectGroup(GroupID, Userid, ProjectID);

            BindGrid();
        }

        private void btnLeaveProject_Click(object sender, EventArgs e)
        {
            int Userid = (int)numUserID.Value;
            int GroupID = (int)numGroupID.Value;
            int ProjectID = (int)numProjectID.Value;

            if (Userid <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "This will remove user from Project in Group! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Groups.LeaveProjectGroup(GroupID, Userid, ProjectID);
            }

            BindGrid();
        }
    }
}
