﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormComponent : Form
    {
        private ServiceManager login;

        public FormComponent(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnGetComponent_Click(object sender, EventArgs e)
        {
            ComponentDto data = login.Projects.GetComponent((int)numProjectID.Value, (int)numID.Value);

            if (data.Entity.Id > 0)
            {
                txtName.Text = data.Entity.Name;
                txtDesc.Text = data.Entity.Description;
                numProjectID.Value = data.Entity.ProjectId;
            }
        }

        private void btnCreateComponent_Click(object sender, EventArgs e)
        {
            var components = new Countersoft.Gemini.Commons.Entity.Component();

            components.Name = txtName.Text;
            components.Description = txtDesc.Text;
            components.ProjectId = Convert.ToInt32(numProjectID.Value);
            components.Lead = Convert.ToInt32(numUserID.Value);


            login.Projects.CreateComponent(components);

            BindGrid();
        }

        private void btnDeleteComponent_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (
                MessageBox.Show(this, "The component will be deleted permantly! Are you sure you want to do this?",
                                "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Projects.DeleteComponent((int)numProjectID.Value, id);
                BindGrid();
            }
        }

        private void btnUpdateComponent_Click(object sender, EventArgs e)
        {
            ComponentDto data = login.Projects.GetComponent((int)numProjectID.Value, (int)numID.Value);
            if (data.Entity.Id > 0)
            {
                data.Entity.Name = txtName.Text;
                data.Entity.Description = txtDesc.Text;
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);
                
                data.Entity.Id = (int)numID.Value;

                login.Projects.UpdateComponent(data.Entity);

                BindGrid();
            }
        }

        private void FormComponent_Load(object sender, EventArgs e)
        {

            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
           // Get all the components.
           // Note that this might throw a security exception.
            var projects = login.Projects.GetProjects();
            dgComponents.DataSource = login.Projects.GetComponents(projects[0].Entity.Id).Select(p => p.Entity).ToList();



        }
    }
}
