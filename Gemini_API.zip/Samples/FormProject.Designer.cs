﻿namespace Test
{
    partial class FormProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProject));
            this.btnUpdateProject = new System.Windows.Forms.Button();
            this.btnGetProject = new System.Windows.Forms.Button();
            this.btnDeleteProject = new System.Windows.Forms.Button();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgProjects = new System.Windows.Forms.DataGrid();
            this.btnCreateProject = new System.Windows.Forms.Button();
            this.numTemplateID = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjects)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTemplateID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdateProject
            // 
            this.btnUpdateProject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateProject.Location = new System.Drawing.Point(504, 547);
            this.btnUpdateProject.Name = "btnUpdateProject";
            this.btnUpdateProject.Size = new System.Drawing.Size(112, 24);
            this.btnUpdateProject.TabIndex = 31;
            this.btnUpdateProject.Text = "Update Project";
            this.btnUpdateProject.Click += new System.EventHandler(this.btnUpdateProject_Click);
            // 
            // btnGetProject
            // 
            this.btnGetProject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetProject.Location = new System.Drawing.Point(376, 547);
            this.btnGetProject.Name = "btnGetProject";
            this.btnGetProject.Size = new System.Drawing.Size(112, 24);
            this.btnGetProject.TabIndex = 30;
            this.btnGetProject.Text = "Get Project";
            this.btnGetProject.Click += new System.EventHandler(this.btnGetProject_Click);
            // 
            // btnDeleteProject
            // 
            this.btnDeleteProject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDeleteProject.Location = new System.Drawing.Point(248, 547);
            this.btnDeleteProject.Name = "btnDeleteProject";
            this.btnDeleteProject.Size = new System.Drawing.Size(112, 24);
            this.btnDeleteProject.TabIndex = 29;
            this.btnDeleteProject.Text = "Delete Project";
            this.btnDeleteProject.Click += new System.EventHandler(this.btnDeleteProject_Click);
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(336, 475);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(213, 477);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 27;
            this.label6.Text = "Project ID:";
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(333, 367);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Size = new System.Drawing.Size(301, 20);
            this.txtDesc.TabIndex = 24;
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(333, 333);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(100, 20);
            this.txtCode.TabIndex = 22;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(333, 299);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(213, 333);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 21;
            this.label2.Text = "Project Code:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(213, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 19;
            this.label1.Text = "Project Name:";
            // 
            // dgProjects
            // 
            this.dgProjects.DataMember = "";
            this.dgProjects.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgProjects.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgProjects.Location = new System.Drawing.Point(0, 0);
            this.dgProjects.Name = "dgProjects";
            this.dgProjects.ReadOnly = true;
            this.dgProjects.Size = new System.Drawing.Size(696, 264);
            this.dgProjects.TabIndex = 18;
            // 
            // btnCreateProject
            // 
            this.btnCreateProject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateProject.Location = new System.Drawing.Point(120, 547);
            this.btnCreateProject.Name = "btnCreateProject";
            this.btnCreateProject.Size = new System.Drawing.Size(112, 24);
            this.btnCreateProject.TabIndex = 17;
            this.btnCreateProject.Text = "Create Project";
            this.btnCreateProject.Click += new System.EventHandler(this.btnCreateProject_Click);
            // 
            // numTemplateID
            // 
            this.numTemplateID.Location = new System.Drawing.Point(333, 399);
            this.numTemplateID.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numTemplateID.Name = "numTemplateID";
            this.numTemplateID.Size = new System.Drawing.Size(100, 20);
            this.numTemplateID.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(213, 367);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 23;
            this.label3.Text = "Project Desc:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(213, 399);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 33;
            this.label4.Text = "Template ID:";
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(333, 435);
            this.numUserID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(100, 20);
            this.numUserID.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(213, 437);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 35;
            this.label5.Text = "User ID:";
            // 
            // FormProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numTemplateID);
            this.Controls.Add(this.btnUpdateProject);
            this.Controls.Add(this.btnGetProject);
            this.Controls.Add(this.btnDeleteProject);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgProjects);
            this.Controls.Add(this.btnCreateProject);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormProject";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Services";
            this.Load += new System.EventHandler(this.FormProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjects)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTemplateID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateProject;
        private System.Windows.Forms.Button btnGetProject;
        private System.Windows.Forms.Button btnDeleteProject;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgProjects;
        private System.Windows.Forms.Button btnCreateProject;
        private System.Windows.Forms.NumericUpDown numTemplateID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.Label label5;
    }
}