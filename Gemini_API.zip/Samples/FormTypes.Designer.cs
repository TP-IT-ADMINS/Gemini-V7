﻿namespace Test
{
    partial class FormTypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTypes));
            this.numTempId = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdateType = new System.Windows.Forms.Button();
            this.btnGetType = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTitleDesc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgTypes = new System.Windows.Forms.DataGrid();
            this.btnCreateType = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numTempId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgTypes)).BeginInit();
            this.SuspendLayout();
            // 
            // numTempId
            // 
            this.numTempId.Location = new System.Drawing.Point(368, 363);
            this.numTempId.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numTempId.Name = "numTempId";
            this.numTempId.Size = new System.Drawing.Size(100, 20);
            this.numTempId.TabIndex = 65;
            this.numTempId.ValueChanged += new System.EventHandler(this.numTempId_ValueChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(248, 365);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 64;
            this.label2.Text = "Template ID:";
            // 
            // btnUpdateType
            // 
            this.btnUpdateType.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateType.Location = new System.Drawing.Point(481, 513);
            this.btnUpdateType.Name = "btnUpdateType";
            this.btnUpdateType.Size = new System.Drawing.Size(103, 24);
            this.btnUpdateType.TabIndex = 63;
            this.btnUpdateType.Text = "Update Type";
            this.btnUpdateType.Click += new System.EventHandler(this.btnUpdateType_Click);
            // 
            // btnGetType
            // 
            this.btnGetType.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetType.Location = new System.Drawing.Point(377, 513);
            this.btnGetType.Name = "btnGetType";
            this.btnGetType.Size = new System.Drawing.Size(90, 24);
            this.btnGetType.TabIndex = 62;
            this.btnGetType.Text = "Get Type";
            this.btnGetType.Click += new System.EventHandler(this.btnGetType_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Location = new System.Drawing.Point(264, 513);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(98, 24);
            this.btnDelete.TabIndex = 61;
            this.btnDelete.Text = "Delete Type";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(368, 408);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 60;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(248, 410);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 59;
            this.label6.Text = "Type ID:";
            // 
            // txtTitleDesc
            // 
            this.txtTitleDesc.Location = new System.Drawing.Point(368, 316);
            this.txtTitleDesc.Name = "txtTitleDesc";
            this.txtTitleDesc.Size = new System.Drawing.Size(184, 20);
            this.txtTitleDesc.TabIndex = 58;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 57;
            this.label1.Text = "Type Desc:";
            // 
            // dgTypes
            // 
            this.dgTypes.DataMember = "";
            this.dgTypes.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgTypes.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgTypes.Location = new System.Drawing.Point(0, 0);
            this.dgTypes.Name = "dgTypes";
            this.dgTypes.ReadOnly = true;
            this.dgTypes.Size = new System.Drawing.Size(696, 264);
            this.dgTypes.TabIndex = 56;
            // 
            // btnCreateType
            // 
            this.btnCreateType.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateType.Location = new System.Drawing.Point(151, 513);
            this.btnCreateType.Name = "btnCreateType";
            this.btnCreateType.Size = new System.Drawing.Size(98, 24);
            this.btnCreateType.TabIndex = 55;
            this.btnCreateType.Text = "Create Type";
            this.btnCreateType.Click += new System.EventHandler(this.btnCreateType_Click);
            // 
            // FormTypes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numTempId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateType);
            this.Controls.Add(this.btnGetType);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTitleDesc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgTypes);
            this.Controls.Add(this.btnCreateType);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTypes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Types";
            this.Load += new System.EventHandler(this.FormTypes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTempId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgTypes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numTempId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdateType;
        private System.Windows.Forms.Button btnGetType;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTitleDesc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgTypes;
        private System.Windows.Forms.Button btnCreateType;
    }
}