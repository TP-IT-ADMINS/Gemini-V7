﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Entity.Security;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormActiveDirectory : Form
    {
        private ServiceManager login;

        public FormActiveDirectory(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormActiveDirectory_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgActiveDirectory.DataSource = login.Groups.GetActiveDirectoryGroups().ToList();
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            ActiveDirectoryGroup data = login.Groups.GetActiveDirectoryGroup((int)numID.Value);
            if (data.Id > 0)
            {
                txtName.Text = data.Name;
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var active = new ActiveDirectoryGroup();

            active.Name = txtName.Text;

            login.Groups.CreateActiveDirectoryGroup(active);

            BindGrid();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ActiveDirectoryGroup data = login.Groups.GetActiveDirectoryGroup((int)numID.Value);

            if (data.Id > 0)
            {
                data.Name = txtName.Text;

                data.Id = Convert.ToInt32((int)numID.Value);

                login.Groups.UpdateActiveDirectoryGroup(data);

                BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Active Directory will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Groups.DeleteActiveDirectoryGroup(id);
            }

            BindGrid();
        }
    }
}
