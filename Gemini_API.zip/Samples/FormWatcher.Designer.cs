﻿namespace Test
{
    partial class FormWatcher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormWatcher));
            this.btnGetWatcher = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.dgWatchers = new System.Windows.Forms.DataGrid();
            this.btnCreateWatcher = new System.Windows.Forms.Button();
            this.numIssueID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgWatchers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGetWatcher
            // 
            this.btnGetWatcher.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetWatcher.Location = new System.Drawing.Point(404, 471);
            this.btnGetWatcher.Name = "btnGetWatcher";
            this.btnGetWatcher.Size = new System.Drawing.Size(126, 24);
            this.btnGetWatcher.TabIndex = 49;
            this.btnGetWatcher.Text = "Get Watcher by Issue ID";
            this.btnGetWatcher.Click += new System.EventHandler(this.btnGetWatcher_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Location = new System.Drawing.Point(302, 471);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(81, 24);
            this.btnDelete.TabIndex = 48;
            this.btnDelete.Text = "Delete Watcher";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(367, 347);
            this.numUserID.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(100, 20);
            this.numUserID.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(247, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 46;
            this.label6.Text = "User ID:";
            // 
            // dgWatchers
            // 
            this.dgWatchers.DataMember = "";
            this.dgWatchers.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgWatchers.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgWatchers.Location = new System.Drawing.Point(0, 0);
            this.dgWatchers.Name = "dgWatchers";
            this.dgWatchers.ReadOnly = true;
            this.dgWatchers.Size = new System.Drawing.Size(696, 264);
            this.dgWatchers.TabIndex = 35;
            // 
            // btnCreateWatcher
            // 
            this.btnCreateWatcher.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateWatcher.Location = new System.Drawing.Point(198, 471);
            this.btnCreateWatcher.Name = "btnCreateWatcher";
            this.btnCreateWatcher.Size = new System.Drawing.Size(82, 24);
            this.btnCreateWatcher.TabIndex = 34;
            this.btnCreateWatcher.Text = "Create Watcher";
            this.btnCreateWatcher.Click += new System.EventHandler(this.btnCreateWatcher_Click);
            // 
            // numIssueID
            // 
            this.numIssueID.Location = new System.Drawing.Point(367, 391);
            this.numIssueID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numIssueID.Name = "numIssueID";
            this.numIssueID.Size = new System.Drawing.Size(100, 20);
            this.numIssueID.TabIndex = 52;
            this.numIssueID.ValueChanged += new System.EventHandler(this.numIssueID_ValueChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(247, 390);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 51;
            this.label2.Text = "Issue ID:";
            // 
            // FormWatcher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numIssueID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnGetWatcher);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgWatchers);
            this.Controls.Add(this.btnCreateWatcher);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormWatcher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Watcher";
            this.Load += new System.EventHandler(this.FormWatcher_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgWatchers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGetWatcher;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGrid dgWatchers;
        private System.Windows.Forms.Button btnCreateWatcher;
        private System.Windows.Forms.NumericUpDown numIssueID;
        private System.Windows.Forms.Label label2;
    }
}