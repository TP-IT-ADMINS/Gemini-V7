﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.TestApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormAdmin : Form
    {
        private ServiceManager login;

        public FormAdmin(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {

        }

        private void btnConfiguration_Click(object sender, EventArgs e)
        {
            FormConfiguration frm = new FormConfiguration(login);
            frm.Show();
        }

        private void btnPermissions_Click(object sender, EventArgs e)
        {
            FormPermissions frm = new FormPermissions(login);
            frm.Show();
        }

        private void btnAlertTemplates_Click(object sender, EventArgs e)
        {
            FormAlertTemplates frm = new FormAlertTemplates(login);
            frm.Show();
        }
    }
}
