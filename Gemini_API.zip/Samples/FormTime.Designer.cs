﻿namespace Test
{
    partial class FormTime
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTime));
            this.btnUpdateTime = new System.Windows.Forms.Button();
            this.btnGetTime = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgTime = new System.Windows.Forms.DataGrid();
            this.btnCreateTime = new System.Windows.Forms.Button();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numIssueID = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numHours = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.numMinutes = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHours)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMinutes)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdateTime
            // 
            this.btnUpdateTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateTime.Location = new System.Drawing.Point(465, 546);
            this.btnUpdateTime.Name = "btnUpdateTime";
            this.btnUpdateTime.Size = new System.Drawing.Size(80, 24);
            this.btnUpdateTime.TabIndex = 50;
            this.btnUpdateTime.Text = "Update Time";
            this.btnUpdateTime.Click += new System.EventHandler(this.btnUpdateTime_Click);
            // 
            // btnGetTime
            // 
            this.btnGetTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetTime.Location = new System.Drawing.Point(361, 546);
            this.btnGetTime.Name = "btnGetTime";
            this.btnGetTime.Size = new System.Drawing.Size(75, 24);
            this.btnGetTime.TabIndex = 49;
            this.btnGetTime.Text = "Get Time";
            this.btnGetTime.Click += new System.EventHandler(this.btnGetTime_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Location = new System.Drawing.Point(265, 546);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 24);
            this.btnDelete.TabIndex = 48;
            this.btnDelete.Text = "Delete Time";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(359, 382);
            this.numUserID.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(100, 20);
            this.numUserID.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(239, 461);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 46;
            this.label6.Text = "Project ID:";
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(360, 281);
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(264, 20);
            this.txtComment.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(240, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 36;
            this.label1.Text = "Comment:";
            // 
            // dgTime
            // 
            this.dgTime.DataMember = "";
            this.dgTime.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgTime.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgTime.Location = new System.Drawing.Point(0, 0);
            this.dgTime.Name = "dgTime";
            this.dgTime.ReadOnly = true;
            this.dgTime.Size = new System.Drawing.Size(696, 264);
            this.dgTime.TabIndex = 35;
            // 
            // btnCreateTime
            // 
            this.btnCreateTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateTime.Location = new System.Drawing.Point(169, 546);
            this.btnCreateTime.Name = "btnCreateTime";
            this.btnCreateTime.Size = new System.Drawing.Size(75, 24);
            this.btnCreateTime.TabIndex = 34;
            this.btnCreateTime.Text = "Create Time";
            this.btnCreateTime.Click += new System.EventHandler(this.btnCreateTime_Click);
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(360, 464);
            this.numProjectID.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(100, 20);
            this.numProjectID.TabIndex = 52;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(240, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 51;
            this.label2.Text = "User ID:";
            // 
            // numIssueID
            // 
            this.numIssueID.Location = new System.Drawing.Point(360, 423);
            this.numIssueID.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numIssueID.Name = "numIssueID";
            this.numIssueID.Size = new System.Drawing.Size(100, 20);
            this.numIssueID.TabIndex = 54;
            this.numIssueID.ValueChanged += new System.EventHandler(this.numIssueID_ValueChanged);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(240, 423);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 53;
            this.label3.Text = "Issue ID:";
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(360, 500);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 56;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(239, 497);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 55;
            this.label4.Text = "Time ID:";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(240, 304);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 58;
            this.label5.Text = "Hours:";
            // 
            // numHours
            // 
            this.numHours.Location = new System.Drawing.Point(360, 304);
            this.numHours.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numHours.Name = "numHours";
            this.numHours.Size = new System.Drawing.Size(100, 20);
            this.numHours.TabIndex = 57;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(239, 339);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 60;
            this.label7.Text = "Minutes:";
            // 
            // numMinutes
            // 
            this.numMinutes.Location = new System.Drawing.Point(359, 337);
            this.numMinutes.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numMinutes.Name = "numMinutes";
            this.numMinutes.Size = new System.Drawing.Size(100, 20);
            this.numMinutes.TabIndex = 59;
            // 
            // FormTime
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numMinutes);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numHours);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numIssueID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateTime);
            this.Controls.Add(this.btnGetTime);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtComment);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgTime);
            this.Controls.Add(this.btnCreateTime);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTime";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Time";
            this.Load += new System.EventHandler(this.FormTime_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHours)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMinutes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateTime;
        private System.Windows.Forms.Button btnGetTime;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgTime;
        private System.Windows.Forms.Button btnCreateTime;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numIssueID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numHours;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numMinutes;
    }
}