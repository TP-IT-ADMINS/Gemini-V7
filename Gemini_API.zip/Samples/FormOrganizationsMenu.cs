﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;

namespace Countersoft.Gemini.TestApi
{
    public partial class FormOrganizationsMenu : Form
    {
        private ServiceManager login;

        public FormOrganizationsMenu(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnOrganizations_Click(object sender, EventArgs e)
        {
            FormOrganizations frm = new FormOrganizations(login);
            frm.Show();
        }

        private void btnOrganizationsMemebership_Click(object sender, EventArgs e)
        {
            FormOrganizationsMemebership frm = new FormOrganizationsMemebership(login);
            frm.Show();
        }
    }
}
