﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormCustomField : Form
    {
        private ServiceManager login;

        public FormCustomField(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnGetCustomField_Click(object sender, EventArgs e)
        {
            CustomFieldDto data = login.CustomFields.Get((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                txtName.Text = data.Entity.Name;
                txtDesc.Text = data.Entity.ScreenDescription;
                txtLabel.Text = data.Entity.ScreenLabel;
                txtToolTip.Text = data.Entity.ScreenTooltip;
                txtType.Text = data.Entity.Type;
                numTemplateID.Value = (data.Entity.TemplateId);
            }
        }

        private void btnCreateCustomField_Click(object sender, EventArgs e)
        {
            var fields = new CustomField();

            fields.Name = txtName.Text;
            fields.ScreenDescription = txtDesc.Text;
            fields.ScreenLabel = txtLabel.Text;
            fields.ScreenTooltip = txtToolTip.Text;
            fields.Type = txtType.Text;
            fields.TemplateId = Convert.ToInt32(numTemplateID.Value);

            login.CustomFields.Create(fields);
        }

        private void btnDeleteCustomField_Click(object sender, EventArgs e)
        {
            int id = (int) numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (
                MessageBox.Show(this, "The custom field will be deleted permantly! Are you sure you want to do this?",
                                "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.CustomFields.Delete(id);
                BindGrid();
            }
        }

        private void btnUpdateCustomField_Click(object sender, EventArgs e)
        {
            CustomFieldDto data = login.CustomFields.Get((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Name = txtName.Text;
                data.Entity.ScreenDescription = txtDesc.Text;
                data.Entity.ScreenLabel = txtLabel.Text;
                data.Entity.ScreenTooltip = txtToolTip.Text;
                data.Entity.Type = txtType.Text;

                data.Entity.Id = (int) numID.Value;


                login.CustomFields.Update(data.Entity);

                BindGrid();
            }
        }

        private void FormCustomField_Load(object sender, EventArgs e)
        {

            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the customfield.
            // Note that this might throw a security exception.
            dgCustomFields.DataSource = login.CustomFields.Get().Select(p => p.Entity).ToList(); 
        }
    }
}
