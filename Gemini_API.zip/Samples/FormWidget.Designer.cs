﻿namespace Test
{
    partial class FormWidget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormWidget));
            this.btnProjectConfiguration = new System.Windows.Forms.Button();
            this.btnItemWidgetData = new System.Windows.Forms.Button();
            this.btnGlobalConfiguration = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnProjectConfiguration
            // 
            this.btnProjectConfiguration.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnProjectConfiguration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectConfiguration.Location = new System.Drawing.Point(106, 84);
            this.btnProjectConfiguration.Name = "btnProjectConfiguration";
            this.btnProjectConfiguration.Size = new System.Drawing.Size(168, 40);
            this.btnProjectConfiguration.TabIndex = 20;
            this.btnProjectConfiguration.Text = "ProjectConfiguration";
            this.btnProjectConfiguration.Click += new System.EventHandler(this.btnProjectConfiguration_Click);
            // 
            // btnItemWidgetData
            // 
            this.btnItemWidgetData.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnItemWidgetData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemWidgetData.Location = new System.Drawing.Point(106, 142);
            this.btnItemWidgetData.Name = "btnItemWidgetData";
            this.btnItemWidgetData.Size = new System.Drawing.Size(168, 40);
            this.btnItemWidgetData.TabIndex = 19;
            this.btnItemWidgetData.Text = "Item Widget Data";
            this.btnItemWidgetData.Click += new System.EventHandler(this.btnItemWidgetData_Click);
            // 
            // btnGlobalConfiguration
            // 
            this.btnGlobalConfiguration.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGlobalConfiguration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGlobalConfiguration.Location = new System.Drawing.Point(106, 28);
            this.btnGlobalConfiguration.Name = "btnGlobalConfiguration";
            this.btnGlobalConfiguration.Size = new System.Drawing.Size(168, 40);
            this.btnGlobalConfiguration.TabIndex = 18;
            this.btnGlobalConfiguration.Text = "Global Configuration";
            this.btnGlobalConfiguration.Click += new System.EventHandler(this.btnGlobalConfiguration_Click);
            // 
            // FormWidget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 209);
            this.Controls.Add(this.btnProjectConfiguration);
            this.Controls.Add(this.btnItemWidgetData);
            this.Controls.Add(this.btnGlobalConfiguration);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormWidget";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Widget";
            this.Load += new System.EventHandler(this.FormWidget_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnProjectConfiguration;
        private System.Windows.Forms.Button btnItemWidgetData;
        private System.Windows.Forms.Button btnGlobalConfiguration;
    }
}