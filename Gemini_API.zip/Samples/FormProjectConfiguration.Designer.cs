﻿namespace Test
{
    partial class FormProjectConfiguration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProjectConfiguration));
            this.dgProjectConfiguration = new System.Windows.Forms.DataGrid();
            this.txtAppId = new System.Windows.Forms.TextBox();
            this.btnGet = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.txtValue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectConfiguration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            this.SuspendLayout();
            // 
            // dgProjectConfiguration
            // 
            this.dgProjectConfiguration.DataMember = "";
            this.dgProjectConfiguration.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgProjectConfiguration.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgProjectConfiguration.Location = new System.Drawing.Point(0, 0);
            this.dgProjectConfiguration.Name = "dgProjectConfiguration";
            this.dgProjectConfiguration.ReadOnly = true;
            this.dgProjectConfiguration.Size = new System.Drawing.Size(696, 264);
            this.dgProjectConfiguration.TabIndex = 40;
            // 
            // txtAppId
            // 
            this.txtAppId.Location = new System.Drawing.Point(302, 424);
            this.txtAppId.Name = "txtAppId";
            this.txtAppId.Size = new System.Drawing.Size(242, 20);
            this.txtAppId.TabIndex = 76;
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(330, 531);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(75, 23);
            this.btnGet.TabIndex = 75;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(204, 424);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 23);
            this.label6.TabIndex = 74;
            this.label6.Text = "App ID:";
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(302, 482);
            this.numProjectID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(148, 20);
            this.numProjectID.TabIndex = 78;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(204, 484);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 23);
            this.label1.TabIndex = 77;
            this.label1.Text = "Project ID:";
            // 
            // txtValue
            // 
            this.txtValue.Location = new System.Drawing.Point(302, 452);
            this.txtValue.Name = "txtValue";
            this.txtValue.Size = new System.Drawing.Size(242, 20);
            this.txtValue.TabIndex = 84;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(204, 455);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 23);
            this.label2.TabIndex = 83;
            this.label2.Text = "Value:";
            // 
            // FormProjectConfiguration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.txtValue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAppId);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgProjectConfiguration);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormProjectConfiguration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Configuration";
            this.Load += new System.EventHandler(this.FormProjectConfiguration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectConfiguration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGrid dgProjectConfiguration;
        private System.Windows.Forms.TextBox txtAppId;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtValue;
        private System.Windows.Forms.Label label2;
    }
}