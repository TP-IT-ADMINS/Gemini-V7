﻿namespace Test
{
    partial class FormComment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormComment));
            this.btnUpdateComment = new System.Windows.Forms.Button();
            this.btnGetComment = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgComment = new System.Windows.Forms.DataGrid();
            this.btnCreateComment = new System.Windows.Forms.Button();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numIssueID = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgComment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdateComment
            // 
            this.btnUpdateComment.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateComment.Location = new System.Drawing.Point(445, 511);
            this.btnUpdateComment.Name = "btnUpdateComment";
            this.btnUpdateComment.Size = new System.Drawing.Size(89, 24);
            this.btnUpdateComment.TabIndex = 50;
            this.btnUpdateComment.Text = "Update Comment";
            this.btnUpdateComment.Click += new System.EventHandler(this.btnUpdateComment_Click);
            // 
            // btnGetComment
            // 
            this.btnGetComment.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetComment.Location = new System.Drawing.Point(364, 511);
            this.btnGetComment.Name = "btnGetComment";
            this.btnGetComment.Size = new System.Drawing.Size(75, 24);
            this.btnGetComment.TabIndex = 49;
            this.btnGetComment.Text = "Get Comment";
            this.btnGetComment.Click += new System.EventHandler(this.btnGetComment_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Location = new System.Drawing.Point(268, 511);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 24);
            this.btnDelete.TabIndex = 48;
            this.btnDelete.Text = "Delete Comment";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(334, 408);
            this.numUserID.Maximum = new decimal(new int[] {
            200000,
            0,
            0,
            0});
            this.numUserID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(100, 20);
            this.numUserID.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(214, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 46;
            this.label6.Text = "User ID:";
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(334, 306);
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(284, 20);
            this.txtComment.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(214, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 36;
            this.label1.Text = "Comment:";
            // 
            // dgComment
            // 
            this.dgComment.DataMember = "";
            this.dgComment.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgComment.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgComment.Location = new System.Drawing.Point(0, 0);
            this.dgComment.Name = "dgComment";
            this.dgComment.ReadOnly = true;
            this.dgComment.Size = new System.Drawing.Size(696, 264);
            this.dgComment.TabIndex = 35;
            // 
            // btnCreateComment
            // 
            this.btnCreateComment.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateComment.Location = new System.Drawing.Point(177, 511);
            this.btnCreateComment.Name = "btnCreateComment";
            this.btnCreateComment.Size = new System.Drawing.Size(85, 24);
            this.btnCreateComment.TabIndex = 34;
            this.btnCreateComment.Text = "Create Comment";
            this.btnCreateComment.Click += new System.EventHandler(this.btnCreateComment_Click);
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(334, 339);
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(100, 20);
            this.numProjectID.TabIndex = 52;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(214, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 51;
            this.label2.Text = "Project ID:";
            // 
            // numIssueID
            // 
            this.numIssueID.Location = new System.Drawing.Point(334, 375);
            this.numIssueID.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.numIssueID.Name = "numIssueID";
            this.numIssueID.Size = new System.Drawing.Size(100, 20);
            this.numIssueID.TabIndex = 54;
            this.numIssueID.ValueChanged += new System.EventHandler(this.numIssueID_ValueChanged);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(214, 375);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 53;
            this.label3.Text = "Issue ID:";
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(334, 444);
            this.numID.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 56;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(214, 443);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 55;
            this.label4.Text = "Comment ID:";
            // 
            // FormComment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numIssueID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateComment);
            this.Controls.Add(this.btnGetComment);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtComment);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgComment);
            this.Controls.Add(this.btnCreateComment);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormComment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comment";
            this.Load += new System.EventHandler(this.FormComment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgComment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numIssueID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdateComment;
        private System.Windows.Forms.Button btnGetComment;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgComment;
        private System.Windows.Forms.Button btnCreateComment;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numIssueID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label4;
    }
}