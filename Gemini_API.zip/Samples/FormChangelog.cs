﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormChangelog : Form
    {
        private ServiceManager login;

        public FormChangelog(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }
        private void FormChangelog_Load(object sender, EventArgs e)
        {
            try
            {
                BindGridVersion();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgChangelog.DataSource = login.Item.GetChangelog(versionId).ToList();

        }

        private void BindGridVersion()
        {
            var projects = login.Projects.GetProjects();
            dgChangelog.DataSource = login.Projects.GetVersions(projects[0].Entity.Id).Select(p => p.Entity).ToList();
        }

        public int versionId { get; set; }

        private void btnGet_Click(object sender, EventArgs e)
        {
            List<IssueDto> data = login.Item.GetChangelog((int)numID.Value);

            BindGrid();
        }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
            versionId = Convert.ToInt32(numID.Value);
            BindGrid();
        }
    }
}
