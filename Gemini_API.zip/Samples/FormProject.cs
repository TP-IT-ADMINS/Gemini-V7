﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormProject : Form
    {
        private ServiceManager login;

        public FormProject(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormProject_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }
        		
        private void BindGrid()
		{
			// Get all the projects.
			// Note that this might throw a security exception.
            dgProjects.DataSource = login.Projects.GetProjects().Select(p => p.Entity).ToList();
		}

        private void btnGetProject_Click(object sender, EventArgs e)
        {
            ProjectDto data = login.Projects.GetProject((int)numID.Value);
            if(data.Entity.Id> 0)
            {
                txtName.Text = data.Entity.Name;
                txtCode.Text = data.Entity.Code;
                txtDesc.Text = data.Entity.Description;
                numUserID.Value = data.Entity.LeadId;
                numTemplateID.Value = data.Entity.TemplateId;
            }
        }

        private void btnCreateProject_Click(object sender, EventArgs e)
        {
            var projects = new Project();

            projects.Name = txtName.Text;
            projects.Code = txtCode.Text;
            projects.Description = txtDesc.Text;
            projects.TemplateId = Convert.ToInt32(numTemplateID.Value);
            projects.LeadId = Convert.ToInt32(numUserID.Value);
            projects.WorkflowId = 1;

            login.Projects.CreateProject(projects);
            BindGrid();
        }

        private void btnDeleteProject_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The project will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Projects.DeleteProject(id);
                BindGrid();
            }
        }

        private void btnUpdateProject_Click(object sender, EventArgs e)
        {

            ProjectDto data = login.Projects.GetProject((int)numID.Value);

            if(data.Entity.Id> 0)
            {
                data.Entity.Name = txtName.Text;
                data.Entity.Description = txtDesc.Text;
                data.Entity.Code = txtCode.Text;
                data.Entity.TemplateId = Convert.ToInt32(numTemplateID.Value);
                data.Entity.LeadId = Convert.ToInt32(numUserID.Value);

                data.Entity.Id = Convert.ToInt32((int)numID.Value);

                login.Projects.UpdateProject(data.Entity);

                BindGrid();
            }
        }
    }
}
