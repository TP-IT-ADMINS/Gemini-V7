﻿using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons;
using Countersoft.Gemini.Commons.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class FormHistory : Form
    {
        private ServiceManager login;

        public FormHistory(ServiceManager sm)
        {
            InitializeComponent();
            
            login = sm;
        }

        private void FormHistory_Load(object sender, EventArgs e)
        {
            try
            {
                //BindGridIssue();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            dgHistory.DataSource = login.Item.GetHistory(id).Select(p => p.Entity).ToList();
        }


        private void btnGet_Click(object sender, EventArgs e)
        {
            List<IssueAuditDto> data = login.Item.GetHistory((int)numID.Value);

            BindGrid();
        }

        public int id { get; set; }

        private void numID_ValueChanged(object sender, EventArgs e)
        {
            id = Convert.ToInt32(numID.Value);
            BindGrid();
        }
    }
}
