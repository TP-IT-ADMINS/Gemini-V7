﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Meta;

namespace Test
{
    public partial class FormTimeTypes : Form
    {
        private ServiceManager login;

        public FormTimeTypes(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void dgTimeTypes_Navigate(object sender, NavigateEventArgs ne)
        {

        }

        private void FormTimeTypes_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }

        }

        private void BindGrid()
        {
            dgTimeTypes.DataSource = login.Meta.GetTimeTypes().ToList();
        }

        private void BindGrid2()
        {
            dgTimeTypes.DataSource = login.Meta.GetTimeTypesForTemplate(templateId).ToList();
        }

        private void btnCreateType_Click(object sender, EventArgs e)
        {
            var type = new TimeType();

            type.Label = txtName.Text;
            type.Description = txtTitleDesc.Text;
            type.TemplateId = Convert.ToInt32(numTempId.Value);

            login.Meta.CreateTimeType(type);

            BindGrid();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Time Type will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Meta.DeleteTimeType((int)numID.Value);
                BindGrid();
            }
        }

        private void btnGetType_Click(object sender, EventArgs e)
        {
            TimeType data = login.Meta.GetTimeType((int)numID.Value);
            if (data.Id > 0)
            {
                txtName.Text = data.Label;
                txtTitleDesc.Text = data.Description;
                numTempId.Value = data.TemplateId;
            }
        }

        private void btnUpdateType_Click(object sender, EventArgs e)
        {
            TimeType data = login.Meta.GetTimeType((int)numID.Value);

            if (data.Id > 0)
            {
                data.Label = txtName.Text;
                data.Description = txtTitleDesc.Text;
                data.TemplateId = Convert.ToInt32(numTempId.Value);


                login.Meta.UpdateTimeType(data);

                BindGrid();
            }
        }

        private void numTempId_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numTempId.Value);
            BindGrid2();
        }


        public int templateId { get; set; }
    }
}
