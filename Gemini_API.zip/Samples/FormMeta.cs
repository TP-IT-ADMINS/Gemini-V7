﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;

namespace Test
{
    public partial class FormMeta : Form
    {
        private ServiceManager login;

        public FormMeta(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnType_Click(object sender, EventArgs e)
        {
            FormTypes frm = new FormTypes(login);
            frm.Show();
        }

        private void btnPriority_Click(object sender, EventArgs e)
        {
            FormPriority frm = new FormPriority(login);
            frm.Show();
        }

        private void btnSeverity_Click(object sender, EventArgs e)
        {
            FormSeverity frm = new FormSeverity(login);
            frm.Show();
        }

        private void btnStatus_Click(object sender, EventArgs e)
        {
            FormStatus frm = new FormStatus(login);
            frm.Show();
        }

        private void btnResolution_Click(object sender, EventArgs e)
        {
            FormResolution frm = new FormResolution(login);
            frm.Show();
        }

        private void FormMeta_Load(object sender, EventArgs e)
        {

        }

        private void btnLinkTypes_Click(object sender, EventArgs e)
        {
            FormLinkTypes frm = new FormLinkTypes(login);
            frm.Show();
        }

        private void btnTimeTypes_Click(object sender, EventArgs e)
        {
            FormTimeTypes frm = new FormTimeTypes(login);
            frm.Show();
        }

    }
}
