using System.Reflection;

[assembly: AssemblyTitle("Countersoft Gemini API Test Harness")]
[assembly: AssemblyDescription("Test the various RESTful API end-points of Gemini")]

[assembly: AssemblyCompany("Countersoft Limited")]
[assembly: AssemblyProduct("Gemini Project Tracking Platform")]
[assembly: AssemblyCopyright("Copyright � Countersoft 2003-2023")]
[assembly: AssemblyTrademark("Countersoft")]

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("7.5.0.7666")]
[assembly: AssemblyFileVersion("7.5.0.7666")]
