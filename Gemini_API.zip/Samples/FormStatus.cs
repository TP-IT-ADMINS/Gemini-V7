﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Meta;

namespace Test
{
    public partial class FormStatus : Form
    {
        private ServiceManager login;

        public FormStatus(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormStatus_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }

        }

        private void BindGrid()
        {
            // Get all the Status.
            // Note that this might throw a security exception.

            dgStatus.DataSource = login.Meta.GetIssuesStatuses().Select(p => p.Entity).ToList();

        }

        private void BindGrid2()
        {
            // Get all the Templates.
            // Note that this might throw a security exception.

            dgStatus.DataSource = login.Meta.GetStatusesForTemplate(templateId).Select(p => p.Entity).ToList();

        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            IssueStatusDto data = login.Meta.GetIssueStatus((int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtTitleDesc.Text = data.Entity.Label;
                numTempId.Value = data.Entity.TemplateId;
                txtComment.Text = data.Entity.Comment;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            IssueStatusDto data = login.Meta.GetIssueStatus((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Label = txtTitleDesc.Text;
                data.Entity.TemplateId = Convert.ToInt32(numTempId.Value);
                data.Entity.Comment = txtComment.Text;


                login.Meta.UpdateIssueStatus(data.Entity);

                BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Status will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Meta.DeleteIssueStatus((int)numID.Value);
                BindGrid();
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            var status = new IssueStatus();

            status.Label = txtTitleDesc.Text;
            status.TemplateId = Convert.ToInt32(numTempId.Value);
            status.Comment = txtComment.Text;


            login.Meta.CreateIssueStatus(status);

            BindGrid();
        }

        public int templateId { get; set; }

        private void numTempId_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numTempId.Value);
            BindGrid2();
        }
    }
}
