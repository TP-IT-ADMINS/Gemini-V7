﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Meta;

namespace Test
{
    public partial class FormSeverity : Form
    {
        private ServiceManager login;

        public FormSeverity(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormSeverity_Load(object sender, EventArgs e)
        {
            try
            {
                 BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the Severities.
            // Note that this might throw a security exception.

            dgSeverity.DataSource = login.Meta.GetIssueSeverities().Select(p => p.Entity).ToList();

        }

        private void BindGrid2()
        {
            // Get all the Templates.
            // Note that this might throw a security exception.

            dgSeverity.DataSource = login.Meta.GetSeveritiesForTemplate(templateId).Select(p => p.Entity).ToList();

        }

        private void btnGetSeverity_Click(object sender, EventArgs e)
        {
            IssueSeverityDto data = login.Meta.GetIssueSeverity((int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtTitleDesc.Text = data.Entity.Label;
                numTempId.Value = data.Entity.TemplateId;
            }
        }

        private void btnUpdateSeverity_Click(object sender, EventArgs e)
        {
            IssueSeverityDto data = login.Meta.GetIssueSeverity((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Label = txtTitleDesc.Text;
                data.Entity.TemplateId = Convert.ToInt32(numTempId.Value);


                login.Meta.UpdateIssueSeverity(data.Entity);

                 BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Severity will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Meta.DeleteIssueSeverity((int)numID.Value);
                BindGrid();
            }
        }

        private void btnCreateSeverity_Click(object sender, EventArgs e)
        {
            var severity = new IssueSeverity();

            severity.Label = txtTitleDesc.Text;
            severity.TemplateId = Convert.ToInt32(numTempId.Value);

            login.Meta.CreateIssueSeverity(severity);

            BindGrid();
        }

        public int templateId { get; set; }

        private void numTempId_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numTempId.Value);
            BindGrid2();
        }

    }
}
