﻿namespace Test
{
    partial class FormVersion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVersion));
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdateVersion = new System.Windows.Forms.Button();
            this.btnGetVersion = new System.Windows.Forms.Button();
            this.btnDeleteVersion = new System.Windows.Forms.Button();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgVersions = new System.Windows.Forms.DataGrid();
            this.btnCreateVersion = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgVersions)).BeginInit();
            this.SuspendLayout();
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(368, 442);
            this.numID.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(120, 20);
            this.numID.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(248, 442);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 32;
            this.label2.Text = "Version ID:";
            // 
            // btnUpdateVersion
            // 
            this.btnUpdateVersion.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateVersion.Location = new System.Drawing.Point(502, 515);
            this.btnUpdateVersion.Name = "btnUpdateVersion";
            this.btnUpdateVersion.Size = new System.Drawing.Size(112, 24);
            this.btnUpdateVersion.TabIndex = 31;
            this.btnUpdateVersion.Text = "Update Version";
            this.btnUpdateVersion.Click += new System.EventHandler(this.btnUpdateVersion_Click);
            // 
            // btnGetVersion
            // 
            this.btnGetVersion.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetVersion.Location = new System.Drawing.Point(374, 515);
            this.btnGetVersion.Name = "btnGetVersion";
            this.btnGetVersion.Size = new System.Drawing.Size(112, 24);
            this.btnGetVersion.TabIndex = 30;
            this.btnGetVersion.Text = "Get Version";
            this.btnGetVersion.Click += new System.EventHandler(this.btnGetVersion_Click);
            // 
            // btnDeleteVersion
            // 
            this.btnDeleteVersion.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDeleteVersion.Location = new System.Drawing.Point(246, 515);
            this.btnDeleteVersion.Name = "btnDeleteVersion";
            this.btnDeleteVersion.Size = new System.Drawing.Size(112, 24);
            this.btnDeleteVersion.TabIndex = 29;
            this.btnDeleteVersion.Text = "Delete Version";
            this.btnDeleteVersion.Click += new System.EventHandler(this.btnDeleteVersion_Click);
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(365, 402);
            this.numProjectID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(120, 20);
            this.numProjectID.TabIndex = 28;
            this.numProjectID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(245, 402);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 27;
            this.label6.Text = "Project ID:";
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(368, 363);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(120, 20);
            this.txtNumber.TabIndex = 26;
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(368, 331);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Size = new System.Drawing.Size(120, 20);
            this.txtDesc.TabIndex = 24;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(368, 299);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(120, 20);
            this.txtName.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(248, 363);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 25;
            this.label4.Text = "Version Number:";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(248, 331);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 23;
            this.label3.Text = "Version Desc:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(248, 299);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 21;
            this.label1.Text = "Version Name:";
            // 
            // dgVersions
            // 
            this.dgVersions.DataMember = "";
            this.dgVersions.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgVersions.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgVersions.Location = new System.Drawing.Point(0, 0);
            this.dgVersions.Name = "dgVersions";
            this.dgVersions.ReadOnly = true;
            this.dgVersions.Size = new System.Drawing.Size(696, 264);
            this.dgVersions.TabIndex = 20;
            // 
            // btnCreateVersion
            // 
            this.btnCreateVersion.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateVersion.Location = new System.Drawing.Point(118, 515);
            this.btnCreateVersion.Name = "btnCreateVersion";
            this.btnCreateVersion.Size = new System.Drawing.Size(112, 24);
            this.btnCreateVersion.TabIndex = 19;
            this.btnCreateVersion.Text = "Create Version";
            this.btnCreateVersion.Click += new System.EventHandler(this.btnCreateVersion_Click);
            // 
            // FormVersion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateVersion);
            this.Controls.Add(this.btnGetVersion);
            this.Controls.Add(this.btnDeleteVersion);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgVersions);
            this.Controls.Add(this.btnCreateVersion);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormVersion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Version Services";
            this.Load += new System.EventHandler(this.FormVersion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgVersions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdateVersion;
        private System.Windows.Forms.Button btnGetVersion;
        private System.Windows.Forms.Button btnDeleteVersion;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgVersions;
        private System.Windows.Forms.Button btnCreateVersion;
    }
}