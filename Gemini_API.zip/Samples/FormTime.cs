﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormTime : Form
    {
        private ServiceManager login;

        public FormTime(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormTime_Load(object sender, EventArgs e)
        {
            try
            {
               //BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the Times.
            // Note that this might throw a security exception.

            dgTime.DataSource = login.Item.GetTimes(issueId).Select(p => p.Entity).ToList();
        }

        private void btnGetTime_Click(object sender, EventArgs e)
        {
            IssueTimeTrackingDto data = login.Item.GetTime((int)numIssueID.Value, (int)numID.Value);
            if (data.Entity.Id>0)
            {
                txtComment.Text = data.Entity.Comment;
                numIssueID.Value = data.Entity.IssueId;
                numProjectID.Value = data.Entity.ProjectId;
                numUserID.Value = data.Entity.UserId;
                numHours.Value = data.Entity.Hours;
                numMinutes.Value = data.Entity.Minutes;

                BindGrid();
            }

        }

        private void btnCreateTime_Click(object sender, EventArgs e)
        {
            var times = new IssueTimeTracking();

            times.Comment = txtComment.Text;
            times.Hours = Convert.ToInt32(numHours.Value);
            times.Minutes = Convert.ToInt32(numMinutes.Value);
            times.IssueId = Convert.ToInt32(numIssueID.Value);
            times.ProjectId = Convert.ToInt32(numProjectID.Value);
            times.UserId = Convert.ToInt32(numUserID.Value);
            times.EntryDate = System.DateTime.Now;

            login.Item.LogTime(times);

            BindGrid();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The time will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.DeleteTime((int)numIssueID.Value, id);
                BindGrid();
            }
        }

        private void btnUpdateTime_Click(object sender, EventArgs e)
        {

            IssueTimeTrackingDto data = login.Item.GetTime((int)numIssueID.Value, (int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Comment = txtComment.Text;
                data.Entity.IssueId = Convert.ToInt32(numIssueID.Value);
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);
                data.Entity.UserId = Convert.ToInt32(numUserID.Value);
                data.Entity.Minutes = Convert.ToInt32(numMinutes.Value);
                data.Entity.Hours = Convert.ToInt32(numHours.Value);

                data.Entity.Id = (int) numID.Value;

                login.Item.EditTime(data.Entity);

                BindGrid();
            }
        }

        public int issueId { get; set; }

        private void numIssueID_ValueChanged(object sender, EventArgs e)
        {
            issueId = Convert.ToInt32(numIssueID.Value);
            BindGrid();
        }

        public int id { get; set; }
    }
}
