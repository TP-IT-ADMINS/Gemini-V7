﻿namespace Test
{
    partial class FormGroups
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGroups));
            this.btnActiveDirectoryMapping = new System.Windows.Forms.Button();
            this.btnProjectGroupMembership = new System.Windows.Forms.Button();
            this.btnActiveDirectory = new System.Windows.Forms.Button();
            this.btnProjectGroups = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnActiveDirectoryMapping
            // 
            this.btnActiveDirectoryMapping.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnActiveDirectoryMapping.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActiveDirectoryMapping.Location = new System.Drawing.Point(106, 204);
            this.btnActiveDirectoryMapping.Name = "btnActiveDirectoryMapping";
            this.btnActiveDirectoryMapping.Size = new System.Drawing.Size(168, 40);
            this.btnActiveDirectoryMapping.TabIndex = 25;
            this.btnActiveDirectoryMapping.Text = "Active Directory Mapping";
            this.btnActiveDirectoryMapping.Click += new System.EventHandler(this.btnActiveDirectoryMapping_Click);
            // 
            // btnProjectGroupMembership
            // 
            this.btnProjectGroupMembership.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnProjectGroupMembership.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectGroupMembership.Location = new System.Drawing.Point(106, 83);
            this.btnProjectGroupMembership.Name = "btnProjectGroupMembership";
            this.btnProjectGroupMembership.Size = new System.Drawing.Size(168, 40);
            this.btnProjectGroupMembership.TabIndex = 24;
            this.btnProjectGroupMembership.Text = "Project Group Membership";
            this.btnProjectGroupMembership.Click += new System.EventHandler(this.btnProjectGroupMembership_Click);
            // 
            // btnActiveDirectory
            // 
            this.btnActiveDirectory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnActiveDirectory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActiveDirectory.Location = new System.Drawing.Point(106, 141);
            this.btnActiveDirectory.Name = "btnActiveDirectory";
            this.btnActiveDirectory.Size = new System.Drawing.Size(168, 40);
            this.btnActiveDirectory.TabIndex = 23;
            this.btnActiveDirectory.Text = "Active Directory";
            this.btnActiveDirectory.Click += new System.EventHandler(this.btnActiveDirectory_Click);
            // 
            // btnProjectGroups
            // 
            this.btnProjectGroups.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnProjectGroups.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectGroups.Location = new System.Drawing.Point(106, 27);
            this.btnProjectGroups.Name = "btnProjectGroups";
            this.btnProjectGroups.Size = new System.Drawing.Size(168, 40);
            this.btnProjectGroups.TabIndex = 22;
            this.btnProjectGroups.Text = "Project Groups";
            this.btnProjectGroups.Click += new System.EventHandler(this.btnProjectGroups_Click);
            // 
            // FormGroups
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 270);
            this.Controls.Add(this.btnActiveDirectoryMapping);
            this.Controls.Add(this.btnProjectGroupMembership);
            this.Controls.Add(this.btnActiveDirectory);
            this.Controls.Add(this.btnProjectGroups);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormGroups";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Groups";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnActiveDirectoryMapping;
        private System.Windows.Forms.Button btnProjectGroupMembership;
        private System.Windows.Forms.Button btnActiveDirectory;
        private System.Windows.Forms.Button btnProjectGroups;
    }
}