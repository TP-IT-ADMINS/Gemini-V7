﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Entity;

namespace Test
{
    public partial class FormComment : Form
    {
        private ServiceManager login;

        public FormComment(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void btnGetComment_Click(object sender, EventArgs e)
        {
            IssueCommentDto data = login.Item.IssueCommentGet((int)numIssueID.Value, (int)numID.Value);

            if (data.Entity.Id>0)
            {
                txtComment.Text = data.Entity.Comment;
                numIssueID.Value = data.Entity.IssueId;
                numProjectID.Value = data.Entity.ProjectId;
                numUserID.Value = data.Entity.UserId;

                BindGrid();
            }
        }

        private void FormComment_Load(object sender, EventArgs e)
        {
            try
			{
				//BindGrid();
			}
			catch(Exception ex)
			{
				MessageBox.Show(this,ex.Message);
				Close();
			}
		}

		private void BindGrid()
		{
			// Get all the comments.
            // Note that this might throw a security exception.

            dgComment.DataSource = login.Item.IssueCommentsGet(issueId).Select(p => p.Entity).ToList();
		}

        private void btnCreateComment_Click(object sender, EventArgs e)
        {
            var comments = new IssueComment();

            comments.Comment = txtComment.Text;
            comments.ProjectId = Convert.ToInt32(numProjectID.Value);
            comments.UserId = Convert.ToInt32(numUserID.Value);
            comments.IssueId = Convert.ToInt32(numIssueID.Value);

            login.Item.IssueCommentCreate(comments);

            BindGrid();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The comment will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Item.IssueCommentDelete((int)numIssueID.Value, id);
                BindGrid();
            }
        }

        private void btnUpdateComment_Click(object sender, EventArgs e)
        {
            IssueCommentDto data = login.Item.IssueCommentGet((int)numIssueID.Value, (int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Comment = txtComment.Text;
                data.Entity.ProjectId = Convert.ToInt32(numProjectID.Value);
                data.Entity.IssueId = Convert.ToInt32(numIssueID.Value);
                data.Entity.UserId = Convert.ToInt32(numUserID.Value);

                data.Entity.Id = (int)numID.Value;

                login.Item.IssueCommentUpdate(data.Entity);

                BindGrid();
            }
        }

        public int issueId { get; set; }

        private void numIssueID_ValueChanged(object sender, EventArgs e)
        {
            issueId = Convert.ToInt32(numIssueID.Value);
            BindGrid();
        }

        public int p { get; set; }
    }
}
