﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Countersoft.Gemini.Api;
using Countersoft.Gemini.Commons.Dto;
using Countersoft.Gemini.Commons.Meta;

namespace Test
{
    public partial class FormPriority : Form
    {
        private ServiceManager login;

        public FormPriority(ServiceManager sm)
        {
            InitializeComponent();

            login = sm;
        }

        private void FormPriority_Load(object sender, EventArgs e)
        {
            try
            {
                 BindGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message);
                Close();
            }
        }

        private void BindGrid()
        {
            // Get all the priorities.
            // Note that this might throw a security exception.

            dgPriority.DataSource = login.Meta.GetIssuePriorities().Select(p => p.Entity).ToList();

        }

        private void BindGrid2()
        {
            // Get all the Templates.
            // Note that this might throw a security exception.

            dgPriority.DataSource = login.Meta.GetPrioritiesForTemplate(templateId).Select(p => p.Entity).ToList();

        }

        private void txtTitleDesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGetPriority_Click(object sender, EventArgs e)
        {

            IssuePriorityDto data = login.Meta.GetIssuePriority((int)numID.Value);
            if (data.Entity.Id > 0)
            {
                txtTitleDesc.Text = data.Entity.Label;
                numTempId.Value = data.Entity.TemplateId;
            }
        }

        private void btnUpdatePriority_Click(object sender, EventArgs e)
        {
            IssuePriorityDto data = login.Meta.GetIssuePriority((int)numID.Value);

            if (data.Entity.Id > 0)
            {
                data.Entity.Label = txtTitleDesc.Text;
                data.Entity.TemplateId = Convert.ToInt32(numTempId.Value);


                login.Meta.UpdateIssuePriority(data.Entity);

                 BindGrid();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = (int)numID.Value;

            if (id <= 0)
            {
                return;
            }

            if (MessageBox.Show(this, "The Priority will be deleted permantly! Are you sure you want to do this?", "Gemini WSE", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                login.Meta.DeleteIssuePriority((int)numID.Value);
                BindGrid();
            }
        }

        private void btnCreatePriority_Click(object sender, EventArgs e)
        {
            var priority = new IssuePriority();

            priority.Label = txtTitleDesc.Text;
            priority.TemplateId = Convert.ToInt32(numTempId.Value);

            login.Meta.CreateIssuePriority(priority);

            BindGrid();
        }

        public int templateId { get; set; }

        private void numTempId_ValueChanged(object sender, EventArgs e)
        {
            templateId = Convert.ToInt32(numTempId.Value);
            BindGrid2();
        }
    }
}
