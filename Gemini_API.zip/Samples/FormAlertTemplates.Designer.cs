﻿namespace Countersoft.Gemini.TestApi
{
    partial class FormAlertTemplates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAlertTemplates));
            this.dgAlertTemplate = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.dgAlertTemplate)).BeginInit();
            this.SuspendLayout();
            // 
            // dgAlertTemplate
            // 
            this.dgAlertTemplate.DataMember = "";
            this.dgAlertTemplate.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgAlertTemplate.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgAlertTemplate.Location = new System.Drawing.Point(0, 0);
            this.dgAlertTemplate.Name = "dgAlertTemplate";
            this.dgAlertTemplate.ReadOnly = true;
            this.dgAlertTemplate.Size = new System.Drawing.Size(696, 264);
            this.dgAlertTemplate.TabIndex = 23;
            // 
            // FormAlertTemplates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.dgAlertTemplate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAlertTemplates";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alert Templates";
            this.Load += new System.EventHandler(this.FormAlertTemplates_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgAlertTemplate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgAlertTemplate;
    }
}