﻿
namespace Test
{
    partial class FormItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormItem));
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btnUpdateItem = new System.Windows.Forms.Button();
            this.btnGetItem = new System.Windows.Forms.Button();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.numProjectID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgIssues = new System.Windows.Forms.DataGrid();
            this.btnCreateItem = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.numUserID = new System.Windows.Forms.NumericUpDown();
            this.OrganizationId = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgIssues)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrganizationId)).BeginInit();
            this.SuspendLayout();
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(608, 938);
            this.numID.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(200, 31);
            this.numID.TabIndex = 31;
            this.numID.ValueChanged += new System.EventHandler(this.numID_ValueChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(362, 938);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 44);
            this.label2.TabIndex = 30;
            this.label2.Text = "Item ID:";
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateItem.Location = new System.Drawing.Point(936, 1000);
            this.btnUpdateItem.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(198, 46);
            this.btnUpdateItem.TabIndex = 29;
            this.btnUpdateItem.Text = "Update Item";
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            // 
            // btnGetItem
            // 
            this.btnGetItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetItem.Location = new System.Drawing.Point(726, 1000);
            this.btnGetItem.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnGetItem.Name = "btnGetItem";
            this.btnGetItem.Size = new System.Drawing.Size(198, 46);
            this.btnGetItem.TabIndex = 28;
            this.btnGetItem.Text = "Get  Item";
            this.btnGetItem.Click += new System.EventHandler(this.btnGetIssue_Click);
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDeleteItem.Location = new System.Drawing.Point(516, 1000);
            this.btnDeleteItem.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(198, 46);
            this.btnDeleteItem.TabIndex = 27;
            this.btnDeleteItem.Text = "Delete  Item";
            this.btnDeleteItem.Click += new System.EventHandler(this.btnDeleteItem_Click);
            // 
            // numProjectID
            // 
            this.numProjectID.Location = new System.Drawing.Point(608, 800);
            this.numProjectID.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.numProjectID.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numProjectID.Name = "numProjectID";
            this.numProjectID.Size = new System.Drawing.Size(200, 31);
            this.numProjectID.TabIndex = 26;
            this.numProjectID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numProjectID.ValueChanged += new System.EventHandler(this.numProjectID_ValueChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(362, 800);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 44);
            this.label6.TabIndex = 25;
            this.label6.Text = "Project ID:";
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(608, 660);
            this.txtDesc.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Size = new System.Drawing.Size(542, 31);
            this.txtDesc.TabIndex = 24;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(608, 598);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(542, 31);
            this.txtTitle.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(362, 660);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 44);
            this.label3.TabIndex = 23;
            this.label3.Text = "Desc:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(362, 598);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 44);
            this.label1.TabIndex = 21;
            this.label1.Text = "Issue Title:";
            // 
            // dgIssues
            // 
            this.dgIssues.DataMember = "";
            this.dgIssues.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgIssues.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgIssues.Location = new System.Drawing.Point(0, 0);
            this.dgIssues.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.dgIssues.Name = "dgIssues";
            this.dgIssues.ReadOnly = true;
            this.dgIssues.Size = new System.Drawing.Size(1392, 508);
            this.dgIssues.TabIndex = 20;
            // 
            // btnCreateItem
            // 
            this.btnCreateItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCreateItem.Location = new System.Drawing.Point(306, 1000);
            this.btnCreateItem.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnCreateItem.Name = "btnCreateItem";
            this.btnCreateItem.Size = new System.Drawing.Size(198, 46);
            this.btnCreateItem.TabIndex = 19;
            this.btnCreateItem.Text = "Create Item";
            this.btnCreateItem.Click += new System.EventHandler(this.btnCreateItem_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(362, 727);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 44);
            this.label4.TabIndex = 32;
            this.label4.Text = "Reported By:";
            // 
            // numUserID
            // 
            this.numUserID.Location = new System.Drawing.Point(608, 723);
            this.numUserID.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.numUserID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numUserID.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.numUserID.Name = "numUserID";
            this.numUserID.Size = new System.Drawing.Size(200, 31);
            this.numUserID.TabIndex = 33;
            // 
            // OrganizationId
            // 
            this.OrganizationId.Location = new System.Drawing.Point(608, 871);
            this.OrganizationId.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.OrganizationId.Name = "OrganizationId";
            this.OrganizationId.Size = new System.Drawing.Size(200, 31);
            this.OrganizationId.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(362, 871);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(200, 44);
            this.label5.TabIndex = 34;
            this.label5.Text = "Organization ID:";
            // 
            // FormItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1392, 1119);
            this.Controls.Add(this.OrganizationId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numUserID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnUpdateItem);
            this.Controls.Add(this.btnGetItem);
            this.Controls.Add(this.btnDeleteItem);
            this.Controls.Add(this.numProjectID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDesc);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgIssues);
            this.Controls.Add(this.btnCreateItem);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "FormItem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Services";
            this.Load += new System.EventHandler(this.FormItem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numProjectID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgIssues)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrganizationId)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnUpdateItem;
        private System.Windows.Forms.Button btnGetItem;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.NumericUpDown numProjectID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgIssues;
        private System.Windows.Forms.Button btnCreateItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numUserID;
        private System.Windows.Forms.NumericUpDown OrganizationId;
        private System.Windows.Forms.Label label5;
    }
}
