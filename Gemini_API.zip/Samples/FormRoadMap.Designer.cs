﻿namespace Test
{
    partial class FormRoadMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRoadMap));
            this.dgRoadMap = new System.Windows.Forms.DataGrid();
            this.btnGet = new System.Windows.Forms.Button();
            this.numID = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgRoadMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).BeginInit();
            this.SuspendLayout();
            // 
            // dgRoadMap
            // 
            this.dgRoadMap.DataMember = "";
            this.dgRoadMap.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgRoadMap.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgRoadMap.Location = new System.Drawing.Point(0, 0);
            this.dgRoadMap.Name = "dgRoadMap";
            this.dgRoadMap.ReadOnly = true;
            this.dgRoadMap.Size = new System.Drawing.Size(696, 264);
            this.dgRoadMap.TabIndex = 36;
            // 
            // btnGet
            // 
            this.btnGet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGet.Location = new System.Drawing.Point(282, 522);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(90, 24);
            this.btnGet.TabIndex = 52;
            this.btnGet.Text = "Get Version";
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // numID
            // 
            this.numID.Location = new System.Drawing.Point(344, 462);
            this.numID.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numID.Name = "numID";
            this.numID.Size = new System.Drawing.Size(100, 20);
            this.numID.TabIndex = 51;
            this.numID.ValueChanged += new System.EventHandler(this.numID_ValueChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(225, 464);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 50;
            this.label6.Text = "Version ID:";
            // 
            // FormRoadMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 582);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.numID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgRoadMap);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormRoadMap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RoadMap";
            this.Load += new System.EventHandler(this.FormRoadMap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgRoadMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numID)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgRoadMap;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.NumericUpDown numID;
        private System.Windows.Forms.Label label6;
    }
}